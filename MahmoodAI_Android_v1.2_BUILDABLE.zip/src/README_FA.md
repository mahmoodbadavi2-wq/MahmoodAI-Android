# Mahmood AI Android — v1.1.0 FINAL ENGINEERING

نسخه نهایی مهندسی پروژه است؛ تمرکز آن روی هسته واقعی، تفکیک معماری، ابزارهای اجرایی، verification/repair، App Factory، Research، فایل، صدا، امنیت و تست است.

## باز کردن پروژه
پروژه را در Android Studio نسخه‌ای که AGP 9.4 را پشتیبانی می‌کند باز کنید، SDK 37 و JDK 17 را فعال کنید و سپس Sync/Build را اجرا کنید.

## نسخه‌ها
AGP 9.4.0 / Gradle 9.6.0 / Kotlin 2.3.21 / compileSdk 37 / minSdk 26 / targetSdk 37.

## ساختار
- `app/src/main/java/com/mahmood/ai/agent` — Agent Runtime و Tooling
- `.../ai` — AI Provider و App Factory
- `.../search` — Research Engine
- `.../files` — Document Intelligence
- `.../legal` — Legal Analyzer/Studio
- `.../voice` — Voice Engine/Analysis/Timeline
- `.../network` — Network/VPN profiles and diagnostics
- `.../security` — Keystore/biometric boundaries
- `.../memory` — Memory repository/search
- `.../build` — Build orchestration/diagnostics
- `.../app` — ViewModel/Application boundary
- `.../ui` — Compose UI

## اصل مهندسی
هیچ قابلیت در README به‌عنوان «واقعی» معرفی نشده مگر اینکه برای آن کد اجرایی یا یک boundary قابل تست وجود داشته باشد.
