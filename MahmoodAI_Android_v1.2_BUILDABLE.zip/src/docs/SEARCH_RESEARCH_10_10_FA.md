# Search & Research 10/10

## Pipeline
1. Query understanding
2. Search provider discovery
3. Normalize URLs
4. Deduplicate
5. Fetch with timeout/retry/cache
6. Parse HTML/JSON/PDF metadata
7. Extract title/date/author/main text
8. Chunk evidence
9. Rank sources
10. Extract claims
11. Compare conflicting claims
12. Verify against independent sources
13. Build citation graph
14. Answer with claim-level citations

## Source model
Source: url, title, publisher, author, date, fetchedAt, contentHash, type, reliabilitySignals.
Evidence: sourceId, quote/span locator, extracted claim, confidence.
Claim: statement, evidenceIds, confidence, conflictSet.

## Reliability
اولویت با official docs، standards، primary sources، peer-reviewed، سپس high-quality secondary sources. تبلیغ، duplicate، scraped copies و source بدون provenance امتیاز پایین می‌گیرند.

## HTTP
HTTPS ترجیحی، redirects محدود، size limit، content-type validation، charset handling، robots/terms respect، cache و ETag در صورت امکان.

## خروجی
هر ادعای مهم باید یا citation داشته باشد یا صریحاً به‌عنوان inference/uncertain مشخص شود.
