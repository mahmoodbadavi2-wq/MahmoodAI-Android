# Gap Matrix — وضعیت v0.7 قبل از اصلاح

| حوزه | وضعیت فعلی | هدف | کار اصلی |
|---|---|---|---|
| Architecture | نیمه‌ماژولار | 10 | جداسازی Activity و domain/data/runtime |
| Agent | preview/limited | 10 | ToolRegistry + execute + verify + repair |
| Search | fetch + Google launcher | 10 | discovery abstraction + evidence/citations |
| AI | generic HTTP | 10 | provider contract + streaming + typed errors |
| Voice | STT/TTS | 10 | real audio engine + analysis + rendering |
| Clone | placeholder | 10 | consented provider integration |
| Files | text only | 10 | PDF/DOCX/OCR/tables |
| Legal | templates | 10 | structured evidence/timeline/source-aware drafting |
| Network | parsers | 10 | QR/subscription/diagnostics/VPN adapter |
| App Factory | skeleton ZIP | 10 | generator + real build + repair |
| Security | partial | 10 | Keystore + audit + redaction |
| Testing | almost none | 10 | unit/integration/UI/CI |
| Build | wrapper jar missing | 10 | real wrapper + CI |
| Observability | minimal | 10 | execution IDs, metrics, redacted logs |
| UI | strong | 10 | preserve while moving logic out of Activity |
