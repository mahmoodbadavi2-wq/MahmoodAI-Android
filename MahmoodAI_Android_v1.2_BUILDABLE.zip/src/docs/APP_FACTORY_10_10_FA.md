# App Factory 10/10

## Pipeline
Prompt → ProductSpec → Architecture → FilePlan → Generate → StaticCheck → Build → ParseBuildLog → Repair → Rebuild → Test → Package → Report.

## ProductSpec
نام، package، min/target SDK، features، screens، data model، permissions، dependencies، backend، theme، localization، tests.

## Generator
Template-based deterministic generator با file manifest و hash. تولید incremental فقط فایل‌های owned را تغییر دهد.

## Build
Gradle wrapper واقعی، JDK/SDK matrix، offline cache در صورت امکان، timeout، build variants.

## Repair
Build log parser باید خطاهای Kotlin/Gradle/resource/manifest/dependency را دسته‌بندی کند و patch محدود تولید کند. پس از patch باید از ابتدا validate شود.

## Artifact
APK/AAB، SHA-256، version، variant، build timestamp، test report و reproducibility metadata.
