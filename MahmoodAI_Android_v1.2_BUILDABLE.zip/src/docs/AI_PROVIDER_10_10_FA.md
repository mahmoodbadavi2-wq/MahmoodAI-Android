# AI Provider Layer 10/10

## قرارداد provider-neutral
- generate(request)
- stream(request)
- embed(request)
- structured(request, schema)
- healthCheck()

## Request
model، system، messages، tools، temperature، maxTokens، responseSchema، timeout، cancellation.

## Response
text، structuredData، usage، finishReason، providerRequestId، citations/toolCalls.

## خطاهای typed
Authentication / RateLimit / Timeout / Network / InvalidRequest / Unsupported / Server / Parse / Safety.

## امنیت
API key فقط در Android Keystore/secure storage. هرگز در source، BuildConfig عمومی، log یا crash report ذخیره نشود.

## Reliability
exponential backoff با jitter، retry فقط برای خطاهای قابل retry، circuit breaker برای خطاهای متوالی، streaming cancellation.
