# Agent Runtime 10/10

## Loop
Understand → Plan → Select Tools → Execute → Observe → Verify → Repair → Re-plan → Finish.

## Tool contract
هر Tool شامل:
- id/name/version
- description/schema
- permissions
- risk level
- timeout
- execute(input, context)
- verifier(output)
- rollback در صورت امکان

## Planner
خروجی structured JSON شامل goal، assumptions، steps، dependencies، expected outputs و verification criteria.

## Runtime
- sequential و parallel step support
- dependency graph
- max steps
- max retries
- deadline
- cancellation
- progress events
- persistent execution record

## Verification
- schema validation
- invariant checks
- source/evidence checks
- artifact existence/hash
- semantic verification توسط provider در صورت نیاز

## Repair
Repair باید علت خطا را classify کند: transient / invalid-input / dependency / permission / build / network / logic.
سپس فقط اصلاح مجاز را انجام دهد و دوباره verify کند. retry بی‌نهایت ممنوع.

## Safety
عملیات نصب APK، تغییر VPN، حذف فایل، ارسال پیام، اجرای کد یا دسترسی حساس باید confirmation policy داشته باشد.
