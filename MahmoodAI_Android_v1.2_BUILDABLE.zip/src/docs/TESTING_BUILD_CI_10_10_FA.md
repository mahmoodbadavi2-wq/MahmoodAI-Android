# Testing / Build / CI 10/10

## Test pyramid
- Unit: domain/agent/parsers/formatters
- Integration: repositories/provider/search/factory
- Instrumented: permissions, storage, install flow
- UI smoke: navigation + core workflows
- Golden/regression: critical generated outputs

## Minimum suites
AgentRuntimeTest، SearchParserTest، CitationTest، ProviderContractTest، VpnParserTest، AppFactoryGenerationTest، BuildLogRepairTest، LegalDraftTest، SecureStoreTest.

## Build
- Gradle wrapper شامل `gradle-wrapper.jar`
- Gradle/AGP/Kotlin/JDK/SDK matrix مستند
- debug + release build
- lint + unit tests + assemble در CI
- dependency locking/version catalog در صورت نیاز

## CI
روی push/PR: formatting → lint → unit → integration → assemble. Artifact و test report ذخیره شود.

## Release gate
No failing tests، no leaked secrets، no TODO pretending to be implementation، no fake success states، reproducible versioning.
