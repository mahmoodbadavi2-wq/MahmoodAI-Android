# Mahmood AI — سند مادر رسیدن به 10/10

این سند معیار معماری و پیاده‌سازی نسخه‌های بعدی است. هدف «نمایش قابلیت» نیست؛ هر قابلیت باید قابل اجرا، قابل آزمون، قابل مشاهده و قابل بازیابی از خطا باشد.

## تعریف 10/10
- قابلیت واقعی: ورودی واقعی → پردازش واقعی → خروجی واقعی؛ بدون mock به‌عنوان قابلیت نهایی.
- معماری: جداسازی UI / Domain / Data / Runtime / Platform و وابستگی یک‌طرفه.
- Agent: برنامه‌ریزی، اجرای ابزار، مشاهده نتیجه، اعتبارسنجی، تعمیر، retry محدود، لغو و گزارش.
- Search: Discover → Fetch → Parse → Extract → Rank → Deduplicate → Compare → Verify → Cite.
- Voice: ضبط واقعی، STT، تحلیل waveform/spectrum/prosody، TTS، timeline و rendering؛ cloning فقط با رضایت و صدای مجاز.
- App Factory: Specification → Generate → Build → Parse → Repair → Rebuild → Artifact.
- Security: secrets در Keystore، حداقل مجوز، redaction لاگ، تأیید کاربر برای عملیات خطرناک.
- Build: پروژه باید با wrapper واقعی، JDK/SDK مشخص و CI قابل build باشد.
- Quality: تست واحد، integration، UI smoke، contract tests و regression suite.

## قانون طلایی
هیچ وضعیت UI با نام‌هایی مثل «انجام شد»، «Verified» یا «Built» ثبت نشود مگر اینکه یک اجرای واقعی و قابل اثبات پشت آن وجود داشته باشد.

## ترتیب توسعه
1. Core Contracts و Architecture
2. Build/CI/Test Infrastructure
3. Agent Runtime
4. AI Provider Layer
5. Search/Research
6. File Intelligence
7. App Factory
8. Voice/Audio Engine
9. Legal Intelligence
10. Network/VPN Studio
11. Security Hardening
12. UI polish و performance

## Definition of Done برای هر feature
- قرارداد ورودی/خروجی مشخص
- implementation واقعی
- خطاهای typed
- timeout/cancellation
- logging امن
- unit test
- integration test در صورت نیاز
- UI stateهای loading/success/error/cancelled
- documentation
- regression test
- بدون secret یا hard-coded credential
