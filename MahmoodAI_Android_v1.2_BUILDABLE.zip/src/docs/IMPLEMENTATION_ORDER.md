# Implementation Order

## Phase A — Foundation
1. Gradle wrapper واقعی + CI
2. package/module boundaries
3. Result/Error/Operation contracts
4. coroutine/cancellation policy
5. secure logging
6. test infrastructure

## Phase B — Core AI Agent
1. ToolRegistry
2. AgentRuntime
3. planner contract
4. verifier
5. repair engine
6. persistent execution history

## Phase C — Research
1. provider abstraction
2. search discovery adapter
3. HTTP fetcher
4. parser/extractor
5. evidence/claim graph
6. rank/dedup/verify/citations

## Phase D — Factory
1. ProductSpec
2. generator
3. build service
4. log parser
5. repair patcher
6. artifact/report

## Phase E — Voice
1. recorder
2. waveform/prosody analyzer
3. STT/TTS adapters
4. timeline model
5. renderer
6. consented cloning adapter

## Phase F — Files/Legal/Network
Implement each against the same domain/result/error conventions.

## Phase G — Hardening
Performance, battery, offline behavior, accessibility, RTL, security audit, regression suite.
