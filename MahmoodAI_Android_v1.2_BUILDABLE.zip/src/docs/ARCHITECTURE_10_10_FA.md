# Architecture 10/10

## لایه‌ها
- `app`: composition root، navigation و dependency wiring
- `presentation`: Compose screens، ViewModels، UI state/events
- `domain`: use cases، entities، policies و interfaces
- `data`: repositories، local persistence، network adapters
- `agent`: planner، runtime، tool registry، verifier، repair engine
- `ai`: provider-neutral AI contracts + adapters
- `search`: discovery/fetch/parse/rank/evidence/citation
- `voice`: recording/STT/TTS/audio analysis/timeline/rendering
- `files`: PDF/DOCX/OCR/table/text pipeline
- `legal`: structured legal workspace، evidence/timeline، drafting
- `network`: parsers، validators، diagnostics و platform VPN adapter
- `factory`: project specification/generation/build/diagnostics/artifacts
- `security`: Keystore، secret store، permissions، redaction، audit
- `device`: diagnostics با APIهای واقعی Android

## قواعد
- UI هیچ HTTP، فایل‌نویسی، build، یا اجرای tool مستقیمی انجام نمی‌دهد.
- Domain از Android UI وابسته نباشد.
- Platform adapter تنها محل دسترسی به APIهای Android باشد.
- هر external operation interface داشته باشد و mock/fake تستی ارائه دهد.
- همه عملیات طولانی coroutine-based و cancellable باشند.
- State machine به‌جای booleanهای متعدد استفاده شود.

## قرارداد اجرای عملیات
`OperationId`, `startedAt`, `finishedAt`, `status`, `inputSummary`, `output`, `error`, `metrics`.

## stateهای استاندارد
Idle / Preparing / Running / Verifying / Repairing / Succeeded / Failed / Cancelled / TimedOut.
