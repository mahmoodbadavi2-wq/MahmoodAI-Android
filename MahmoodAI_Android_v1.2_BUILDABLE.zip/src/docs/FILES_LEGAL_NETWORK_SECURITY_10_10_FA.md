# File Intelligence / Legal / Network / Security

## File Intelligence
PDF text + page coordinates، OCR برای صفحات تصویری، DOCX paragraphs/tables، XLSX/CSV، image metadata، chunking، search، compare و citation به page/line.

## Legal Intelligence
ساختار: facts، parties، timeline، allegations، evidence، contradictions، requests، legal bases، draft. هیچ نتیجه حقوقی به‌عنوان قطعی بدون source قانونی معتبر ارائه نشود. قابلیت citation به ماده/منبع و ثبت version/date منبع.

## Network/VPN
Parsers برای VLESS/VMess/Trojan/SS/WireGuard؛ validation schema؛ QR import/export؛ subscription parser؛ DNS/TLS/SNI/transport diagnostics؛ platform adapter برای VPN. هیچ credential در log.

## Security
Android Keystore، biometric gate برای secrets، least privilege، network security config، certificate policy در صورت نیاز، encrypted local DB، redacted logs، audit trail، export/delete controls، secure temp files.
