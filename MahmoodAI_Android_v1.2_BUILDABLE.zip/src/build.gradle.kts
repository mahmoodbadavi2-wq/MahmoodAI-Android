plugins {
    id("com.android.application") version "9.4.0" apply false
    id("org.jetbrains.kotlin.android") version "2.3.21" apply false
    id("org.jetbrains.kotlin.plugin.compose") version "2.3.21" apply false
}

tasks.register("verifyArchitecture") {
    group = "verification"
    description = "Checks the expected Mahmood AI modular source layout."
    doLast {
        val required = listOf(
            "app/src/main/java/com/mahmood/ai/agent/AgentCore.kt",
            "app/src/main/java/com/mahmood/ai/search/SearchAgent.kt",
            "app/src/main/java/com/mahmood/ai/ai/AiProvider.kt",
            "app/src/main/java/com/mahmood/ai/ai/AppFactory.kt",
            "app/src/main/java/com/mahmood/ai/app/AppViewModel.kt",
            "app/src/main/java/com/mahmood/ai/files/DocumentIntelligence.kt",
            "app/src/main/java/com/mahmood/ai/legal/LegalAnalyzer.kt",
            "app/src/main/java/com/mahmood/ai/app/AppViewModel.kt",
            "app/src/main/java/com/mahmood/ai/files/DocumentIntelligence.kt",
            "app/src/main/java/com/mahmood/ai/legal/LegalAnalyzer.kt",
            "app/src/main/java/com/mahmood/ai/voice/VoiceTimeline.kt",
            "app/src/main/java/com/mahmood/ai/network/VpnLink.kt"
        )
        required.forEach { check(file(it).exists()) { "Missing required module: $it" } }
        println("Mahmood AI architecture check: OK")
    }
}
