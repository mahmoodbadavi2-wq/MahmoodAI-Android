# v1.2 Buildable — تغییرات این مرحله

- نسخه 1.2.0 / versionCode 12
- buildTypes debug/release
- packaging cleanup
- test configuration
- Gradle 9.6 bootstrap برای Windows/Linux در صورت نبود Gradle سیستم
- اسکریپت بررسی JDK/Android SDK
- اسکریپت Build واقعی و جمع‌آوری APK
- نام ریشه پروژه اصلاح شد
- proguard-rules.pro اضافه شد
- مسیر خروجی استاندارد `dist/`

## معیار عبور
این نسخه فقط زمانی «واقعاً اجرایی» محسوب می‌شود که روی سیستم دارای Android SDK و JDK 17:
`testDebugUnitTest` و `assembleDebug` با موفقیت اجرا شوند و APK تولید شود.
