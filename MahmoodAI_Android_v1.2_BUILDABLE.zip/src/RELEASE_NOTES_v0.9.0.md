# MahmoodAI Android v0.9.0

## Major upgrade
- Agent Runtime is now exposed through a single MahmoodAgentService gateway.
- UI Agent execution uses real registered tools instead of preview-only planning.
- Search Workspace runs ResearchEngine: discovery, fetch, extraction, deduplication, evidence and citations.
- Real PCM16 WAV feature extraction: duration, RMS dB, peak dB, zero-crossing rate and pitch estimate.
- Network validation layer added on top of VLESS/VMess/Trojan/SS parsing.
- App Factory now emits a stronger Android/Compose project skeleton with dependency management, Compose UI and build instructions.
- Version bumped to 0.9.0.

## Honest limitation
The current container still has no Android SDK and no Gradle runtime/wrapper JAR, so a final APK compilation cannot be claimed from this environment. Source-level and pure-Kotlin checks are performed where possible.
