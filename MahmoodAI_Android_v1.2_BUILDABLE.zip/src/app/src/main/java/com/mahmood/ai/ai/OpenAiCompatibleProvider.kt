package com.mahmood.ai.ai

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** OpenAI-compatible chat endpoint adapter. Endpoint/model/key are runtime configuration only. */
class OpenAiCompatibleProvider(private val endpoint: String, private val apiKey: String, private val model: String) : AiProvider {
    override suspend fun generate(prompt: String, system: String): String = withContext(Dispatchers.IO) {
        runCatching {
            val c = URL(endpoint).openConnection() as HttpURLConnection
            c.connectTimeout = 15_000; c.readTimeout = 60_000; c.requestMethod = "POST"; c.doOutput = true
            c.setRequestProperty("Content-Type", "application/json")
            if (apiKey.isNotBlank()) c.setRequestProperty("Authorization", "Bearer $apiKey")
            val messages = JSONArray().apply {
                if (system.isNotBlank()) put(JSONObject().put("role", "system").put("content", system))
                put(JSONObject().put("role", "user").put("content", prompt))
            }
            val body = JSONObject().put("model", model).put("messages", messages).put("temperature", 0.2)
            c.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            val response = (if (c.responseCode in 200..299) c.inputStream else c.errorStream).bufferedReader().use { it.readText() }
            if (c.responseCode !in 200..299) error("HTTP ${c.responseCode}: ${response.take(500)}")
            val json = JSONObject(response)
            json.optJSONArray("choices")?.optJSONObject(0)?.optJSONObject("message")?.optString("content")
                ?.takeIf { it.isNotBlank() } ?: json.optString("text").ifBlank { response }
        }.getOrElse { throw IllegalStateException("AI provider failed: ${it.message}", it) }
    }
}
