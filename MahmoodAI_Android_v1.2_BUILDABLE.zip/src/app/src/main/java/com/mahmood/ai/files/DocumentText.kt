package com.mahmood.ai.files

import java.io.File

object DocumentText{
    fun readText(file:File,maxChars:Int=2_000_000):String{
        require(file.exists() && file.isFile)
        return file.inputStream().bufferedReader(Charsets.UTF_8).use{it.readText().take(maxChars)}
    }
    fun search(text:String,query:String):List<Int>{
        if(query.isBlank()) return emptyList(); val out=mutableListOf<Int>(); var p=0
        while(true){val i=text.indexOf(query,p,true);if(i<0)break;out+=i;p=i+query.length};return out
    }
}
