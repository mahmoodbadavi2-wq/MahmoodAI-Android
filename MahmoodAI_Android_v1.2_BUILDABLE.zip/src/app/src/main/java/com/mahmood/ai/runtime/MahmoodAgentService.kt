package com.mahmood.ai.runtime

import com.mahmood.ai.agent.*
import com.mahmood.ai.core.events.AgentEvent
import com.mahmood.ai.core.events.AgentEventSink
import com.mahmood.ai.core.model.ExecutionResult
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class MahmoodAgentService(private val sink:AgentEventSink?=null){
 private val registry=ToolRegistry(ProductionToolsV10().tools())
 private val runtime=AgentRuntimeV10(registry,ResultVerifier{_,r->r.ok&&r.output.isNotBlank()})
 suspend fun execute(request:String):ExecutionResult=withContext(Dispatchers.IO){runtime.run(request)}
}
