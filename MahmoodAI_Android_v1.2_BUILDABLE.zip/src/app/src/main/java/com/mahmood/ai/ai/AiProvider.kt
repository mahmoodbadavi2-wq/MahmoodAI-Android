package com.mahmood.ai.ai

import java.net.HttpURLConnection
import java.net.URL
import org.json.JSONObject

/** Provider boundary: secrets are supplied at runtime, never hard-coded. */
interface AiProvider { suspend fun generate(prompt: String, system: String = ""): String }
class DisabledAiProvider : AiProvider { override suspend fun generate(prompt: String, system: String): String = "AI Provider متصل نیست؛ خروجی محلی/قالبی استفاده شد." }

class JsonHttpAiProvider(private val endpoint: String, private val apiKey: String, private val model: String) : AiProvider {
    override suspend fun generate(prompt: String, system: String): String = runCatching {
        val c = URL(endpoint).openConnection() as HttpURLConnection
        c.connectTimeout = 15000; c.readTimeout = 30000; c.requestMethod = "POST"
        c.doOutput = true; c.setRequestProperty("Content-Type", "application/json")
        if (apiKey.isNotBlank()) c.setRequestProperty("Authorization", "Bearer $apiKey")
        val body = JSONObject().put("model", model).put("system", system).put("prompt", prompt).toString()
        c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
        val response = c.inputStream.bufferedReader().use { it.readText() }
        JSONObject(response).optString("text").ifBlank { response }
    }.getOrElse { "Provider error: ${it.message ?: "unknown"}" }
}
