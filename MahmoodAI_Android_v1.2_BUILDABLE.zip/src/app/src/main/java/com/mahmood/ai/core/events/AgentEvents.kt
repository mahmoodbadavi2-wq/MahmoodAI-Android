package com.mahmood.ai.core.events

import com.mahmood.ai.core.model.ExecutionStage

sealed interface AgentEvent {
    data class Started(val requestId:String,val request:String):AgentEvent
    data class Stage(val requestId:String,val stage:ExecutionStage):AgentEvent
    data class Finished(val requestId:String,val success:Boolean,val output:String):AgentEvent
}
fun interface AgentEventSink { fun emit(event:AgentEvent) }
