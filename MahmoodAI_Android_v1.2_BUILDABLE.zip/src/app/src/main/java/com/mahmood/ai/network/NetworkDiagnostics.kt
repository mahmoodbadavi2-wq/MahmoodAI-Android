package com.mahmood.ai.network

data class NetworkDiagnostic(val valid:Boolean,val issues:List<String>,val checks:Map<String,Boolean>)
object NetworkDiagnostics {
    fun validate(link:String):NetworkDiagnostic {
        val p=VpnLink.parse(link.trim()); val issues=mutableListOf<String>()
        if(p==null) issues+="فرمت کانفیگ پشتیبانی‌شده تشخیص داده نشد"
        val checks=mapOf("scheme" to (p!=null),"host" to (p?.host?.isNotBlank()==true),"port" to (p?.port?.let { it in 1..65535 } == true),"type" to (p?.type in setOf("VLESS","VMESS","TROJAN","SS","WIREGUARD")))
        if(!checks.getValue("host")) issues+="host نامعتبر است"; if(!checks.getValue("port")) issues+="port نامعتبر است"
        return NetworkDiagnostic(issues.isEmpty(),issues,checks)
    }
}
