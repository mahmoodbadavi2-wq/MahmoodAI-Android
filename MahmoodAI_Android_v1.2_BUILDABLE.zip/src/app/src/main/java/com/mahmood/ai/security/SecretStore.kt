package com.mahmood.ai.security

import android.content.Context
import android.util.Base64
import java.security.MessageDigest

/** Minimal secret boundary; production keys should be migrated to Android Keystore-backed storage. */
class SecretStore(context:Context){
    private val prefs=context.getSharedPreferences("mahmood_secret_meta",Context.MODE_PRIVATE)
    fun fingerprint(secret:String):String=MessageDigest.getInstance("SHA-256").digest(secret.toByteArray()).let{Base64.encodeToString(it,Base64.NO_WRAP)}
    fun markConfigured(name:String){prefs.edit().putBoolean(name,true).apply()}
    fun isConfigured(name:String)=prefs.getBoolean(name,false)
}
