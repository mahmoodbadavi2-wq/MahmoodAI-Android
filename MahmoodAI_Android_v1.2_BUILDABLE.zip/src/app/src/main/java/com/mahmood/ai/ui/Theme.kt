package com.mahmood.ai.ui

import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val NeonCyan = Color(0xFF00D9FF)
private val NeonPurple = Color(0xFF8B5CFF)
private val NeonPink = Color(0xFFFF4FD8)
private val DeepBg = Color(0xFF070810)
private val Surface = Color(0xFF111423)
private val Surface2 = Color(0xFF171B2C)

@Composable
fun MahmoodTheme(content: @Composable () -> Unit) {
    val colors = darkColorScheme(
        primary = NeonCyan,
        onPrimary = Color(0xFF001014),
        secondary = NeonPurple,
        tertiary = NeonPink,
        background = DeepBg,
        onBackground = Color(0xFFF5F7FF),
        surface = Surface,
        surfaceVariant = Surface2,
        onSurface = Color(0xFFF5F7FF),
        onSurfaceVariant = Color(0xFFB9BED0),
        outline = Color(0xFF30364D)
    )
    MaterialTheme(colorScheme = colors, typography = Typography(), content = content)
}
