package com.mahmood.ai.files

import android.content.Context
import java.io.File

object FileTools{
    fun saveText(context:Context,name:String,text:String):File{val f=File(context.filesDir,name); f.writeText(text); return f}
    fun readText(file:File):String=runCatching{file.readText()}.getOrDefault("")
}
