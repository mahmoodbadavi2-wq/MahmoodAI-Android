package com.mahmood.ai.legal

data class LegalIssue(val title:String,val facts:List<String>,val evidence:List<String>,val requests:List<String>,val warnings:List<String>)
object LegalAnalyzer {
    fun analyze(text:String):LegalIssue {
        val lines=text.lines().map{it.trim()}.filter{it.isNotBlank()}
        val evidence=lines.filter{it.contains("مدرک")||it.contains("سند")||it.contains("گزارش")||it.contains("صوت")||it.contains("تصویر")}
        val facts=lines.filter{it !in evidence}.take(30)
        val warnings=mutableListOf<String>()
        if(evidence.isEmpty()) warnings+="مستندات به‌صورت صریح شناسایی نشدند."
        if(lines.size<3) warnings+="اطلاعات برای تحلیل کامل کافی نیست."
        return LegalIssue("تحلیل اولیه حقوقی",facts,evidence,listOf("بررسی ادعاها و مستندات اصلی","بررسی تناقض‌های احتمالی","تنظیم متن نهایی پس از تطبیق با اسناد"),warnings)
    }
}
