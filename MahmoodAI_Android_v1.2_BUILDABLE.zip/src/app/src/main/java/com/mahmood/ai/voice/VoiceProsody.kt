package com.mahmood.ai.voice

data class ProsodySpec(
    val speed: Float = 1f,
    val pitch: Float = 1f,
    val intensity: Float = 1f,
    val pauseBeforeMs: Long = 0,
    val pauseAfterMs: Long = 0,
    val emphasis: Set<String> = emptySet(),
    val stretched: Set<String> = emptySet(),
    val emotion: String = "طبیعی",
    val dialect: String = "استاندارد"
)

object VoiceDirector {
    fun interpret(instruction: String, base: ProsodySpec = ProsodySpec()): ProsodySpec {
        var p = base
        val s = instruction.lowercase()
        if ("آرام" in s) p = p.copy(speed = .82f, intensity = .9f)
        if ("سریع" in s || "عجله" in s) p = p.copy(speed = 1.18f)
        if ("آرام‌تر" in s) p = p.copy(speed = (p.speed - .08f).coerceAtLeast(.5f))
        if ("بلند" in s) p = p.copy(intensity = 1.18f)
        if ("آهسته" in s) p = p.copy(intensity = .86f)
        if ("جدی" in s) p = p.copy(emotion = "جدی")
        if ("عصبانی" in s) p = p.copy(emotion = "عصبانی", intensity = 1.15f)
        if ("غمگین" in s) p = p.copy(emotion = "غمگین", speed = .9f)
        if ("شاد" in s) p = p.copy(emotion = "شاد", intensity = 1.05f)
        Regex("(?:مکث|فاصله).{0,20}(\\d+)\\s*(?:میلی|ms)").find(s)?.groupValues?.getOrNull(1)?.toLongOrNull()?.let { p = p.copy(pauseAfterMs = it) }
        return p
    }
}
