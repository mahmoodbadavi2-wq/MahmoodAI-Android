package com.mahmood.ai.agent

import com.mahmood.ai.core.events.AgentEvent
import com.mahmood.ai.core.events.AgentEventSink
import com.mahmood.ai.core.model.ExecutionRequest
import com.mahmood.ai.core.model.ExecutionResult
import com.mahmood.ai.core.model.ExecutionStage
import kotlinx.coroutines.withTimeout
import java.util.UUID

class AgentRuntimeV11(
    private val registry: ToolRegistry,
    private val verifier: ResultVerifier,
    private val repairer: ResultRepairer,
    private val policy: AgentPolicy = AgentPolicy(3,120_000),
    private val sink: AgentEventSink? = null
) {
    suspend fun run(text:String):ExecutionResult=run(ExecutionRequest(UUID.randomUUID().toString(),text))
    suspend fun run(request:ExecutionRequest):ExecutionResult=withTimeout(policy.timeoutMs){
        require(request.text.isNotBlank())
        val plan=AgentCore.plan(request.text); val stages=mutableListOf<ExecutionStage>()
        fun stage(name:String,state:String,detail:String,attempt:Int=0){val x=ExecutionStage(name,state,detail,attempt);stages+=x;sink?.emit(AgentEvent.Stage(request.id,x))}
        sink?.emit(AgentEvent.Started(request.id,request.text))
        stage("Understand","✓","Intent=${plan.intent}"); stage("Plan","✓",plan.steps.joinToString(" → "))
        val tool=registry.get(plan.intent) ?: registry.get("GENERAL")
        if(tool==null){stage("SelectTool","✗","No tool");return@withTimeout finish(request,plan.intent,false,0,"No executable tool",stages)}
        stage("SelectTool","✓",plan.intent)
        var last=ToolResult(false,error="not executed")
        for(attempt in 1..policy.maxAttempts){
            stage("Execute","…","attempt=$attempt",attempt)
            last=tool.execute(ToolContext(request.text,attempt,request.metadata+mapOf("requestId" to request.id,"intent" to plan.intent)))
            stage("Execute",if(last.ok)"✓" else "✗",last.output.ifBlank{last.error?:"error"},attempt)
            if(last.ok && verifier.verify(request.text,last)){stage("Verify","✓","verified",attempt);return@withTimeout finish(request,plan.intent,true,attempt,last.output,stages)}
            stage("Verify","✗",last.error?:"verification failed",attempt)
            if(attempt<policy.maxAttempts){stage("Repair","↻","failure analysis + repair",attempt);last=repairer.repair(request.text,last,attempt+1)}
        }
        finish(request,plan.intent,false,policy.maxAttempts,last.error?:"unverified result",stages)
    }
    private fun finish(r:ExecutionRequest,intent:String,ok:Boolean,attempts:Int,out:String,stages:List<ExecutionStage>):ExecutionResult{
        val result=ExecutionResult(r.id,intent,ok,attempts,out,stages,if(ok)null else out);sink?.emit(AgentEvent.Finished(r.id,ok,out));return result
    }
}
