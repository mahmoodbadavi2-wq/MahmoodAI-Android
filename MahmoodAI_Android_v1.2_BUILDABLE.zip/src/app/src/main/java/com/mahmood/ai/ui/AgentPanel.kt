package com.mahmood.ai.ui

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.height
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.mahmood.ai.app.AppViewModel

@Composable
fun AgentPanel(request: String, onResult: (String) -> Unit, vm: AppViewModel = viewModel()) {
    val state by vm.state.collectAsStateWithLifecycle()
    Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF101321))) {
        Column(Modifier.padding(14.dp)) {
            Text("AGENT RUNTIME", color = Color(0xFF00D9FF), style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(6.dp))
            Text(if (state.running) "Understand → Plan → Execute → Verify → Repair" else "Runtime آماده است.", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            state.error?.let { Text("✗ $it", color = Color(0xFFFF6B7A), fontSize = 12.sp) }
            state.result?.let { result ->
                Text("${if (result.success) "✓" else "✗"} ${result.output}", fontSize = 12.sp)
                Spacer(Modifier.height(5.dp))
                Text(result.stages.joinToString("\n") { "${it.state} ${it.name}: ${it.detail}" }, fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Spacer(Modifier.height(8.dp))
            Button(enabled = request.isNotBlank() && !state.running, onClick = { vm.execute(request); onResult("Agent execution started") }, modifier = Modifier.fillMaxWidth()) {
                Text(if (state.running) "در حال اجرا…" else "اجرای واقعی Agent")
            }
        }
    }
}
