package com.mahmood.ai.memory

data class RankedMemory(val key:String,val text:String,val score:Double)
object MemorySearch {
    fun rank(items:Map<String,String>,query:String):List<RankedMemory>{
        val terms=query.lowercase().split(Regex("\\W+")).filter{it.length>=2}
        return items.map{(k,v)->val low=v.lowercase();val hits=terms.count{low.contains(it)};RankedMemory(k,v,hits.toDouble()/terms.size.coerceAtLeast(1))}.filter{it.score>0}.sortedByDescending{it.score}
    }
}
