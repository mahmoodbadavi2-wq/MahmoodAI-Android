package com.mahmood.ai.data

import android.content.Context
import org.json.JSONArray

class ProjectStore(context: Context) {
    private val prefs = context.getSharedPreferences("mahmood_projects", Context.MODE_PRIVATE)

    fun add(name: String, type: String) {
        val list = JSONArray(prefs.getString("items", "[]"))
        list.put("$type|$name")
        prefs.edit().putString("items", list.toString()).apply()
    }

    fun recent(): List<String> {
        val list = JSONArray(prefs.getString("items", "[]"))
        return buildList {
            for (i in (list.length() - 1).coerceAtLeast(0) downTo 0) add(list.optString(i))
        }.take(6)
    }
}
