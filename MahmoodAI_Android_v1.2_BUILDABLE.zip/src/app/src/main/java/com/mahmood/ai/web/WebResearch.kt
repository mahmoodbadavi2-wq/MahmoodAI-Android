package com.mahmood.ai.web

import android.content.Context
import android.content.Intent
import android.net.Uri

object WebResearch { fun openSearch(context:Context,q:String){context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q="+Uri.encode(q))))} }
