package com.mahmood.ai.voice

import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import java.util.Locale

class VoiceEngine(private val context: Context) {
    private var recognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var initialized = false

    fun startListening(language: String = "fa-IR", onText: (String) -> Unit, onPartial: (String) -> Unit = {}, onError: (String) -> Unit = {}) {
        stopSpeaking()
        if (!SpeechRecognizer.isRecognitionAvailable(context)) { onError("سرویس تشخیص گفتار در دسترس نیست"); return }
        recognizer?.destroy()
        recognizer = if (Build.VERSION.SDK_INT >= 31 && SpeechRecognizer.isOnDeviceRecognitionAvailable(context))
            SpeechRecognizer.createOnDeviceSpeechRecognizer(context) else SpeechRecognizer.createSpeechRecognizer(context)
        recognizer!!.setRecognitionListener(object : RecognitionListener {
            override fun onResults(b: Bundle?) { onText(b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()) }
            override fun onPartialResults(b: Bundle?) { onPartial(b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()) }
            override fun onError(e: Int) { onError("خطای تشخیص گفتار: $e") }
            override fun onReadyForSpeech(p: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(r: Float) {}
            override fun onBufferReceived(b: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onEvent(t: Int, b: Bundle?) {}
        })
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, language)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
        }
        recognizer!!.startListening(i)
    }

    fun stopListening() { recognizer?.stopListening() }
    fun stopSpeaking() { tts?.stop() }

    fun speak(text: String, spec: ProsodySpec = ProsodySpec(), language: Locale = Locale("fa", "IR")) {
        if (tts == null) {
            tts = TextToSpeech(context) { status ->
                initialized = status == TextToSpeech.SUCCESS
                if (initialized) speakNow(text, spec, language)
            }
        } else speakNow(text, spec, language)
    }

    private fun speakNow(text: String, spec: ProsodySpec, language: Locale) {
        if (!initialized && tts != null) return
        tts?.language = language
        tts?.setSpeechRate(spec.speed.coerceIn(.5f, 2f))
        tts?.setPitch(spec.pitch.coerceIn(.5f, 2f))
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "mahmood_${System.nanoTime()}")
    }

    fun release() { recognizer?.destroy(); recognizer = null; tts?.shutdown(); tts = null; initialized = false }
}
