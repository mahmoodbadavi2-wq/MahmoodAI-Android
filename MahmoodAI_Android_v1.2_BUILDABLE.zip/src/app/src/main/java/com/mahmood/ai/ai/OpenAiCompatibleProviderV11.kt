package com.mahmood.ai.ai

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

data class AiResponse(val text:String,val model:String,val raw:String,val usageTokens:Int?=null)
interface StreamingAiProvider:AiProvider { suspend fun generateStructured(prompt:String,system:String=""):AiResponse }
class OpenAiCompatibleProviderV11(private val endpoint:String,private val apiKey:String,private val model:String):StreamingAiProvider{
    override suspend fun generate(prompt:String,system:String):String=generateStructured(prompt,system).text
    override suspend fun generateStructured(prompt:String,system:String):AiResponse=withContext(Dispatchers.IO){
        val c=URL(endpoint).openConnection() as HttpURLConnection
        c.connectTimeout=20_000;c.readTimeout=60_000;c.requestMethod="POST";c.doOutput=true;c.setRequestProperty("Content-Type","application/json");if(apiKey.isNotBlank())c.setRequestProperty("Authorization","Bearer $apiKey")
        val messages=JSONArray().put(JSONObject().put("role","system").put("content",system)).put(JSONObject().put("role","user").put("content",prompt))
        c.outputStream.use{it.write(JSONObject().put("model",model).put("messages",messages).put("temperature",0.2).toString().toByteArray())}
        val code=c.responseCode;val raw=(if(code in 200..299)c.inputStream else c.errorStream).bufferedReader().use{it.readText()};if(code !in 200..299)error("AI HTTP $code: ${raw.take(500)}")
        val j=JSONObject(raw);val choices=j.optJSONArray("choices");val text=choices?.optJSONObject(0)?.optJSONObject("message")?.optString("content").orEmpty().ifBlank{j.optString("text").ifBlank{raw}};AiResponse(text,j.optString("model",model),raw,j.optJSONObject("usage")?.optInt("total_tokens"))
    }
}
