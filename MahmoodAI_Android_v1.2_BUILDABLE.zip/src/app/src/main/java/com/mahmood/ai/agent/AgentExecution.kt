package com.mahmood.ai.agent

/** Small deterministic execution engine. Tools are injected so the core is testable and replaceable. */
data class AgentStage(val title: String, val state: String, val detail: String = "")
data class AgentRun(val request: String, val stages: List<AgentStage>, val result: String = "")

fun interface AgentTool { fun run(input: String): Result<String> }

/** Legacy synchronous facade kept for the UI; new code should use AgentRuntime. */

class AgentExecutor(private val tools: Map<String, AgentTool> = emptyMap()) {
    fun execute(request: String): AgentRun {
        val plan = AgentCore.plan(request)
        val stages = mutableListOf<AgentStage>()
        stages += AgentStage("درک درخواست", "✓", "Intent=${plan.intent}")
        stages += AgentStage("برنامه‌ریزی", "✓", plan.steps.joinToString(" → "))
        val tool = tools[plan.intent]
        val execution = tool?.run(request) ?: Result.success("برای Intent=${plan.intent} ابزار اجرایی ثبت نشده است.")
        stages += AgentStage("اجرا", if (execution.isSuccess) "✓" else "✗", execution.getOrElse { it.message ?: "خطای ناشناخته" })
        val verification = if (execution.isSuccess) "✓ نتیجه تولید شد؛ خروجی برای بررسی نهایی آماده است." else "✗ اجرا ناموفق بود؛ Repair موردنیاز است."
        stages += AgentStage("بررسی نتیجه", if (execution.isSuccess) "✓" else "✗", verification)
        stages += AgentStage("اصلاح خودکار", if (execution.isSuccess) "—" else "○", if (execution.isSuccess) "نیازی به Repair اولیه نیست." else "Repair باید توسط ابزار تخصصی انجام شود.")
        stages += AgentStage("نتیجه نهایی", if (execution.isSuccess) "✓" else "✗", execution.getOrElse { "اجرا ناموفق بود." })
        return AgentRun(request, stages, execution.getOrElse { it.message ?: "خطا" })
    }
}

object AgentExecution {
    fun preview(request: String): AgentRun = AgentExecutor().execute(request)
}
