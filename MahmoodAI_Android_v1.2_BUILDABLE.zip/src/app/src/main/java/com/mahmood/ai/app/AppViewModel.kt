package com.mahmood.ai.app

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.mahmood.ai.agent.*
import com.mahmood.ai.core.model.ExecutionResult
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class AppViewModel(app:Application):AndroidViewModel(app){
    private val _state=MutableStateFlow(AppState());val state:StateFlow<AppState>=_state.asStateFlow()
    private val registry=ToolRegistry(ProductionToolSetFinal(app.applicationContext).tools())
    private val runtime=AgentRuntimeV11(registry,DefaultResultVerifier,ProductionRepairer(registry),sink=null)
    fun execute(text:String){if(text.isBlank())return;_state.value=_state.value.copy(running=true,error=null);viewModelScope.launch{runCatching{runtime.run(text)}.onSuccess{_state.value=_state.value.copy(running=false,result=it)}.onFailure{_state.value=_state.value.copy(running=false,error=it.message?:"خطا")}}}
}
data class AppState(val running:Boolean=false,val result:ExecutionResult?=null,val error:String?=null)
