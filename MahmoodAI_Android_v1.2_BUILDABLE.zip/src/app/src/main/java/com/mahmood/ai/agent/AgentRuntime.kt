package com.mahmood.ai.agent

import kotlinx.coroutines.withTimeout

/** Production-oriented agent runtime: tool selection, bounded retries, verification and repair. */
data class ToolContext(val request: String, val attempt: Int, val metadata: Map<String, String> = emptyMap())
data class ToolResult(val ok: Boolean, val output: String = "", val error: String? = null, val metadata: Map<String, String> = emptyMap())
fun interface RuntimeTool { suspend fun execute(context: ToolContext): ToolResult }
fun interface ResultVerifier { suspend fun verify(request: String, result: ToolResult): Boolean }
fun interface ResultRepairer { suspend fun repair(request: String, failed: ToolResult, attempt: Int): ToolResult }

data class AgentPolicy(val maxAttempts: Int = 3, val timeoutMs: Long = 60_000L) { init { require(maxAttempts >= 1); require(timeoutMs > 0) } }
data class AgentExecutionResult(val intent: String, val attempts: Int, val verified: Boolean, val stages: List<AgentStage>, val result: String)

class ToolRegistry(private val tools: Map<String, RuntimeTool>) {
    fun get(intent: String): RuntimeTool? = tools[intent]
    fun intents(): Set<String> = tools.keys
}

class AgentRuntime(
    private val registry: ToolRegistry,
    private val verifier: ResultVerifier,
    private val repairer: ResultRepairer,
    private val policy: AgentPolicy = AgentPolicy()
) {
    suspend fun run(request: String): AgentExecutionResult = withTimeout(policy.timeoutMs) {
        val plan = AgentCore.plan(request)
        val stages = mutableListOf<AgentStage>()
        stages += AgentStage("درک درخواست", "✓", "Intent=${plan.intent}")
        stages += AgentStage("برنامه‌ریزی", "✓", plan.steps.joinToString(" → "))
        val tool = registry.get(plan.intent)
        if (tool == null) {
            val msg = "ابزار اجرایی برای Intent=${plan.intent} ثبت نشده است."
            stages += AgentStage("انتخاب ابزار", "✗", msg)
            return@withTimeout AgentExecutionResult(plan.intent, 0, false, stages + AgentStage("نتیجه نهایی", "✗", msg), msg)
        }
        stages += AgentStage("انتخاب ابزار", "✓", plan.intent)
        var last = ToolResult(false, error = "not executed")
        for (attempt in 1..policy.maxAttempts) {
            stages += AgentStage("اجرا #$attempt", "…", "در حال اجرا")
            last = if (attempt == 1) tool.execute(ToolContext(request, attempt))
                   else repairer.repair(request, last, attempt)
            stages[stages.lastIndex] = AgentStage("اجرا #$attempt", if (last.ok) "✓" else "✗", last.output.ifBlank { last.error ?: "خطا" })
            if (last.ok && verifier.verify(request, last)) {
                stages += AgentStage("تأیید نتیجه", "✓", "نتیجه توسط Verifier تأیید شد.")
                stages += AgentStage("نتیجه نهایی", "✓", last.output)
                return@withTimeout AgentExecutionResult(plan.intent, attempt, true, stages, last.output)
            }
            stages += AgentStage("تأیید نتیجه", "✗", if (last.error.isNullOrBlank()) "Verification failed" else last.error!! )
            if (attempt < policy.maxAttempts) stages += AgentStage("Repair/Re-plan", "↻", "تلاش بعدی با مسیر اصلاحی")
        }
        val failure = last.error ?: "نتیجه قابل تأیید نبود."
        stages += AgentStage("نتیجه نهایی", "✗", failure)
        AgentExecutionResult(plan.intent, policy.maxAttempts, false, stages, failure)
    }
}
