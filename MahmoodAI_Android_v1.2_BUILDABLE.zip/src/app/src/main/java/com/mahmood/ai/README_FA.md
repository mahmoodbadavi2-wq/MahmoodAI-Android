# Mahmood AI Android v0.4

نسخه توسعه‌یافته پروژه شخصی Mahmood AI برای Android / Samsung A56 5G.

## آماده شده
- VOICE به‌عنوان بخش اصلی
- Speech → Text با SpeechRecognizer و تلاش برای On‑Device در API 31+
- Text → Speech با Android TTS
- AI Conversation Studio: تبدیل توضیح طبیعی به Timeline چندگوینده، overlap و sync word
- مدل پروژه صوتی و Voice Profiles پایه
- Network Center و parser برای VLESS / VMess / Trojan / Shadowsocks
- تولید قالب VLESS/Trojan/SS برای اطلاعات مجاز خود کاربر
- Device Diagnostics: RAM/Storage/Battery/Android
- APK picker + نصب از مسیر رسمی Android با تأیید کاربر
- Face AI: تشخیص چهره با ML Kit + tracking؛ پروفایل محلی و آماده توسعه embedding
- Biometric Gate برای احراز هویت دستگاه
- حافظه محلی
- AI Core با routing ساده بین Voice/Legal/Network/Device/App Install
- Legal Studio پایه
- Web Search launcher

## هنوز نیازمند اتصال واقعی
1. اتصال AI Provider (OpenAI/مدل محلی/سرور شخصی) و نگهداری امن کلید API
2. موتور واقعی Voice Clone/TTS چندگوینده و رندر WAV/MP3
3. Face embedding + liveness برای شناسایی هویت واقعی؛ ML Kit صرفاً چهره را تشخیص می‌دهد
4. Xray/V2Ray engine واقعی یا اتصال به اپ VPN؛ این پروژه فعلاً لینک/کانفیگ را مدیریت می‌کند و خودش تونل VPN نمی‌سازد
5. App Factory کامل و build کردن پروژه‌های تولیدشده
6. Web fetch/citation engine و ابزارهای فایل/PDF/DOCX
7. Agent loop: Plan → Execute → Verify → Repair

## سازگاری
این پروژه برای Android Studio Quail 4 / 2026.1.4 و AGP 9.4 تنظیم شده است. AGP 9.4 با API 37 و Gradle 9.6 سازگار است.

## ساخت
پروژه را در Android Studio باز کن، Gradle Sync را انجام بده، SDK API 37 و Build Tools لازم را نصب کن و سپس Run را روی A56 اجرا کن.
