package com.mahmood.ai.face

import android.content.Context

class FaceProfileStore(context:Context){
    private val p=context.getSharedPreferences("face_profiles",Context.MODE_PRIVATE)
    fun enroll(name:String){p.edit().putString("owner",name).apply()}
    fun owner():String=p.getString("owner","").orEmpty()
}
