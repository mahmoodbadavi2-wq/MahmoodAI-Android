package com.mahmood.ai.agent

import android.content.Context
import com.mahmood.ai.ai.AppFactoryPipeline
import com.mahmood.ai.files.DocumentIntelligence
import com.mahmood.ai.legal.LegalAnalyzer
import com.mahmood.ai.network.NetworkDiagnostics
import com.mahmood.ai.search.ResearchEngine
import com.mahmood.ai.voice.VoiceAnalyzer
import java.io.File

/** Application-facing production tools. Side effects are bounded to explicit user requests. */
class ProductionToolSetFinal(private val context: Context, private val research: ResearchEngine = ResearchEngine()) {
    fun tools(): Map<String, RuntimeTool> = mapOf(
        "SEARCH" to RuntimeTool { c ->
            val r = research.research(c.request, limit = 8)
            if (r.sources.isEmpty()) ToolResult(false, error = r.warnings.joinToString("; ").ifBlank { "منبع قابل دسترسی پیدا نشد" })
            else ToolResult(true, buildString {
                appendLine("تحقیق: ${r.sources.size} منبع")
                r.evidence.take(12).forEach { e -> appendLine("• ${e.excerpt} [${r.citations.indexOfFirst { it.url == e.sourceUrl } + 1}]") }
                appendLine("منابع:")
                r.citations.forEach { appendLine("[${it.id}] ${it.title} — ${it.url}") }
                r.warnings.forEach { appendLine("هشدار: $it") }
            })
        },
        "NETWORK" to RuntimeTool { c ->
            val d = NetworkDiagnostics.validate(c.request)
            if (!d.valid) ToolResult(false, error = d.issues.joinToString(" | "))
            else ToolResult(true, d.checks.entries.joinToString("\n") { "${it.key}: ${it.value}" })
        },
        "APP_FACTORY" to RuntimeTool { c ->
            val r = AppFactoryPipeline.prepare(context, c.request)
            if (!r.success || r.project == null) ToolResult(false, error = r.issues.joinToString(" | "))
            else ToolResult(true, "پروژه تولید شد: ${r.project.zipFile.absolutePath}\n${r.steps.joinToString("\n") { "${it.state} ${it.name}: ${it.detail}" }}")
        },
        "FILES" to RuntimeTool { c ->
            val file = File(c.request.trim())
            if (!file.exists()) ToolResult(false, error = "فایل پیدا نشد: ${file.path}")
            else {
                val report = DocumentIntelligence.inspect(file)
                ToolResult(true, "${report.name} | ${report.type}\n${report.text.take(6000)}\nقطعات: ${report.fragments.size}\n${report.warnings.joinToString("\n")}")
            }
        },
        "LEGAL" to RuntimeTool { c ->
            val a = LegalAnalyzer.analyze(c.request)
            ToolResult(true, buildString {
                appendLine(a.title); appendLine("واقعیات:"); a.facts.forEach { appendLine("• $it") }
                appendLine("مستندات:"); a.evidence.forEach { appendLine("• $it") }
                appendLine("درخواست‌های پیشنهادی:"); a.requests.forEach { appendLine("• $it") }
                a.warnings.forEach { appendLine("هشدار: $it") }
            })
        },
        "VOICE" to RuntimeTool { c ->
            val a = VoiceAnalyzer.analyzeTextTiming(c.request)
            ToolResult(true, "${a.estimatedWords} واژه | ${a.estimatedWpm} WPM | ${a.durationMs}ms\n${a.notes.joinToString("\n")}")
        },
        "GENERAL" to RuntimeTool { c -> ToolResult(true, "درخواست دریافت شد. Intent=${AgentCore.plan(c.request).intent}") }
    )
}
