package com.mahmood.ai.files

import java.io.File
import java.util.zip.ZipFile

data class DocumentFragment(val index:Int,val text:String,val source:String)
data class DocumentReport(val name:String,val type:String,val text:String,val fragments:List<DocumentFragment>,val warnings:List<String>)

object DocumentIntelligence {
    fun inspect(file:File):DocumentReport {
        require(file.exists() && file.isFile) { "فایل وجود ندارد" }
        return when(file.extension.lowercase()){
            "txt","md","csv","json","html","htm" -> fromText(file)
            "docx" -> fromDocx(file)
            "pdf" -> fromPdf(file)
            else -> DocumentReport(file.name,file.extension,"",emptyList(),listOf("فرمت برای استخراج متن پشتیبانی کامل ندارد"))
        }
    }
    private fun fromText(f:File):DocumentReport { val t=f.readText(); return report(f,f.extension,t) }
    private fun fromDocx(f:File):DocumentReport {
        val xml=ZipFile(f).use{z->z.getEntry("word/document.xml")?.let{z.getInputStream(it).bufferedReader().readText()}?:""}
        val t=xml.replace(Regex("</w:p>"),"\n").replace(Regex("<w:tab[^>]*/>"),"\t").replace(Regex("<[^>]+>"),"").replace("&amp;","&").replace("&lt;","<").replace("&gt;",">").trim()
        return report(f,"docx",t)
    }
    private fun fromPdf(f:File):DocumentReport {
        val raw=f.readBytes().toString(Charsets.ISO_8859_1)
        val strings=Regex("\\(([^()]{1,500})\\)").findAll(raw).map{it.groupValues[1]}.filter{it.any(Char::isLetterOrDigit)}.joinToString(" ")
        return DocumentReport(f.name,"pdf",strings,fragments(strings,f.name),if(strings.isBlank())listOf("PDF اسکن‌شده/فونت‌گذاری‌شده ممکن است به OCR نیاز داشته باشد") else emptyList())
    }
    private fun report(f:File,type:String,text:String)=DocumentReport(f.name,type,text,fragments(text,f.name),emptyList())
    private fun fragments(text:String,source:String):List<DocumentFragment> = text.split(Regex("\\n{2,}|(?<=[.!?])\\s+(?=\\p{L})")).map{it.trim()}.filter{it.isNotBlank()}.mapIndexed{ i,t->DocumentFragment(i+1,t,source)}
    fun compare(a:DocumentReport,b:DocumentReport):List<String>{
        val aa=a.fragments.map{it.text}.toSet(); return b.fragments.map{it.text}.filter{it !in aa}.take(50)
    }
    fun search(report:DocumentReport,query:String):List<DocumentFragment>{val terms=query.lowercase().split(Regex("\\s+")).filter{it.length>2};return report.fragments.filter{f->terms.count{f.text.lowercase().contains(it)}>=1}.take(50)}
}
