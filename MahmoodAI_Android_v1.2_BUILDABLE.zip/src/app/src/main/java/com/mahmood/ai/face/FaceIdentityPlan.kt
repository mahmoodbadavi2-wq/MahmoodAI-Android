package com.mahmood.ai.face

/**
 * Identity layer plan: ML Kit detects/tracks a face; a future local embedding model can compare
 * enrolled authorized profiles. Do not use this for covert identification.
 */
data class FaceProfile(val id:String,val displayName:String,val consented:Boolean=true)
object FaceIdentityPlan{
    fun nextSteps()=listOf("Face Detection","Local Enrollment","Face Embedding","Liveness / Anti-Spoof","Local Encrypted Profile")
}
