package com.mahmood.ai.network

import android.util.Base64
import com.mahmood.ai.data.VpnProfile
import java.net.URI
import org.json.JSONObject

object VpnLink {
    private val supported=setOf("vless","vmess","trojan","ss","wireguard")
    fun parse(link:String):VpnProfile? {
        val raw=link.trim()
        if(raw.startsWith("wireguard://",true)) return parseWireGuard(raw)
        val uri=runCatching{URI(raw)}.getOrNull() ?: return null
        val scheme=uri.scheme?.lowercase() ?: return null
        if(scheme !in supported) return null
        if(scheme=="vmess") return parseVmess(raw)
        val host=uri.host ?: return null; val port=uri.port.takeIf{it>0} ?: return null
        return VpnProfile(scheme.uppercase(),host,port,uri.userInfo?.substringBefore(':')?: "",uri.fragment?.removePrefix("#")?: "",uri.rawQuery.orEmpty(),raw)
    }
    private fun parseVmess(raw:String):VpnProfile? = runCatching {
        val data=raw.substringAfter("vmess://"); val json=String(Base64.decode(data,Base64.DEFAULT),Charsets.UTF_8); val o=JSONObject(json)
        VpnProfile("VMESS",o.optString("add"),o.optInt("port"),o.optString("id"),o.optString("ps"),"",raw)
    }.getOrNull()
    private fun parseWireGuard(raw:String):VpnProfile? = runCatching {
        val body=raw.removePrefix("wireguard://"); val uri=URI("wireguard://$body")
        val host=uri.host ?: return@runCatching null; val port=uri.port.takeIf{it>0} ?: 51820
        VpnProfile("WIREGUARD",host,port,uri.userInfo.orEmpty(),uri.fragment.orEmpty(),uri.rawQuery.orEmpty(),raw)
    }.getOrNull()
    fun validate(link:String)=if(parse(link)!=null) "✓ لینک قابل پردازش است" else "✗ لینک نامعتبر یا ناقص است"
    fun buildVless(id:String,host:String,port:Int,name:String="",type:String="tcp",security:String="none"):String="vless://$id@$host:$port?type=$type&security=$security#${java.net.URLEncoder.encode(name,"UTF-8")}"
    fun buildTrojan(password:String,host:String,port:Int,name:String=""):String="trojan://$password@$host:$port#${java.net.URLEncoder.encode(name,"UTF-8")}"
    fun buildShadowsocks(userInfo:String,host:String,port:Int,name:String=""):String="ss://$userInfo@$host:$port#${java.net.URLEncoder.encode(name,"UTF-8")}"
    fun buildWireGuard(publicKey:String,host:String,port:Int,name:String=""):String="wireguard://$publicKey@$host:$port#${java.net.URLEncoder.encode(name,"UTF-8")}"
}
