package com.mahmood.ai.voice

data class TimelineSegment(val speaker: String, val text: String, val startMs: Long, val endMs: Long)
data class TimelineEdit(val type: String, val segment: Int, val amountMs: Long, val note: String = "")
object VoiceTimeline {
    fun shift(s: List<TimelineSegment>, index: Int, deltaMs: Long): List<TimelineSegment> =
        s.mapIndexed { i, x -> if (i >= index) x.copy(startMs = x.startMs + deltaMs, endMs = x.endMs + deltaMs) else x }
    fun pauseBetween(s: List<TimelineSegment>, index: Int, ms: Long): List<TimelineSegment> {
        if (index !in 0 until s.size - 1) return s
        return s.mapIndexed { i, x -> if (i > index) x.copy(startMs = x.startMs + ms, endMs = x.endMs + ms) else x }
    }
    fun overlap(s: List<TimelineSegment>, first: Int, second: Int, ms: Long): List<TimelineSegment> {
        if (first !in s.indices || second !in s.indices) return s
        val target = s[second]
        return s.mapIndexed { i, x -> if (i == second) x.copy(startMs = (target.startMs - ms).coerceAtLeast(0), endMs = target.endMs - ms) else x }
    }
}
