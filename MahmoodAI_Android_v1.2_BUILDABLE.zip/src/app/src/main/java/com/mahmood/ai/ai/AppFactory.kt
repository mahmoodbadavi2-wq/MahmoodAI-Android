package com.mahmood.ai.ai

import android.content.Context
import java.io.File
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

data class AppFactoryPlan(val platform: String, val name: String, val features: List<String>, val notes: String)
data class GeneratedProject(val plan: AppFactoryPlan, val zipFile: File)

object AppFactory {
    fun plan(instruction: String): AppFactoryPlan {
        val platform = if (instruction.contains("ویندوز", true) || instruction.contains("windows", true)) "Windows" else "Android"
        val features = Regex("(?:با|شامل|دارای)\\s+([^,،.]+)").findAll(instruction).map { it.groupValues[1].trim() }.toList() +
            instruction.split(',', '،', '\n').map { it.trim() }.filter { it.isNotEmpty() }.take(12)
        return AppFactoryPlan(platform, "Mahmood Generated App", features.distinct().take(20), "پروژه شامل Manifest، Compose، ساختار Gradle و فایل مشخصات تولید شد.")
    }

    fun generateAndroidProject(context: Context, instruction: String): GeneratedProject {
        val plan = plan(instruction)
        val dir = File(context.cacheDir, "mahmood_factory").apply { mkdirs() }
        val zip = File(dir, "${safe(plan.name)}_${System.currentTimeMillis()}.zip")
        val packageName = "com.mahmood.generated"
        val settings = """import org.gradle.api.initialization.resolve.RepositoriesMode

pluginManagement { repositories { google(); mavenCentral(); gradlePluginPortal() } }
dependencyResolutionManagement { repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS); repositories { google(); mavenCentral() } }
rootProject.name="GeneratedMahmoodApp"
include(":app")
"""
        val rootBuild = """plugins {
    id("com.android.application") version "9.4.0" apply false
    id("org.jetbrains.kotlin.android") version "2.3.21" apply false
    id("org.jetbrains.kotlin.plugin.compose") version "2.3.21" apply false
}
"""
        val appBuild = """plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}
android {
    namespace="$packageName"
    compileSdk=37
    defaultConfig { applicationId="$packageName"; minSdk=26; targetSdk=37; versionCode=1; versionName="1.0" }
}
dependencies {
    implementation("androidx.core:core-ktx:1.18.0")
    implementation("androidx.activity:activity-compose:1.13.0")
    implementation("androidx.compose.ui:ui:1.12.1")
    implementation("androidx.compose.material3:material3:1.4.0")
}
"""
        val activity = """package $packageName

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.foundation.layout.padding

class MainActivity: ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { GeneratedScreen() }
    }
}
@Composable private fun GeneratedScreen() {
    MaterialTheme { Surface { Text("Mahmood Generated App\\n\\n$instruction", modifier=Modifier.padding(24.dp)) } }
}
"""
        ZipOutputStream(zip.outputStream()).use { out ->
            add(out, "settings.gradle.kts", settings)
            add(out, "build.gradle.kts", rootBuild)
            add(out, "app/build.gradle.kts", appBuild)
            add(out, "app/src/main/AndroidManifest.xml", """<manifest xmlns:android="http://schemas.android.com/apk/res/android"><application android:theme="@style/AppTheme" android:label="Mahmood Generated App"><activity android:name=".MainActivity" android:exported="true"><intent-filter><action android:name="android.intent.action.MAIN"/><category android:name="android.intent.category.LAUNCHER"/></intent-filter></activity></application></manifest>""")
            add(out, "app/src/main/res/values/styles.xml", """<resources><style name="AppTheme" parent="android:style/Theme.Material.Light.NoActionBar"/></resources>""")
            add(out, "app/src/main/java/com/mahmood/generated/MainActivity.kt", activity)
            add(out, "MAHMOOD_FACTORY_PLAN.txt", "Platform: ${plan.platform}\nName: ${plan.name}\nFeatures:\n${plan.features.joinToString("\n- ", prefix="- ")}\n\nBUILD PIPELINE:\nGenerate -> Sync -> Compile -> Test -> Diagnose -> Repair -> Rebuild -> Verify\n")
            add(out, "BUILD_INSTRUCTIONS.txt", "Use Android Studio with JDK 17, Android SDK 37 and Gradle 9.6+. Open the project root and run assembleDebug.\n")
        }
        return GeneratedProject(plan, zip)
    }

    private fun add(out: ZipOutputStream, path: String, content: String) { out.putNextEntry(ZipEntry(path)); out.write(content.toByteArray(Charsets.UTF_8)); out.closeEntry() }
    private fun safe(s: String) = s.replace(Regex("[^A-Za-z0-9_-]"), "_").take(60)
}
