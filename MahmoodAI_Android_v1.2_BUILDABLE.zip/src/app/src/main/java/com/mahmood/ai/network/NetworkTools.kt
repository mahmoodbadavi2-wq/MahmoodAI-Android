package com.mahmood.ai.network

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities

object NetworkTools {
    fun status(context:Context):String {
        val cm=context.getSystemService(ConnectivityManager::class.java) ?: return "شبکه نامشخص"
        val n=cm.activeNetwork ?: return "اتصال فعال نیست"
        val c=cm.getNetworkCapabilities(n) ?: return "اتصال فعال نیست"
        val type=when { c.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)->"Wi‑Fi"; c.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR)->"داده همراه"; c.hasTransport(NetworkCapabilities.TRANSPORT_VPN)->"VPN"; else->"شبکه دیگر" }
        return "اتصال: $type | اینترنت: ${c.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)}"
    }
}
