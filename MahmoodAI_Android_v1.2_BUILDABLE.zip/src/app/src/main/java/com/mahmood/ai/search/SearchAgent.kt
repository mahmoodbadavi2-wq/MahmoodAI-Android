package com.mahmood.ai.search

import android.content.Context
import android.content.Intent
import android.net.Uri
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

 data class SearchSource(val url: String, val title: String, val text: String)
data class ResearchReport(val query: String, val sources: List<SearchSource>, val citations: List<String>)

class SearchAgent(private val context: Context) {
    fun openSearch(query: String) {
        context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(query))))
    }

    fun fetchText(url: String, maxChars: Int = 20000): Result<String> = runCatching {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 8000
        c.readTimeout = 12000
        c.instanceFollowRedirects = true
        c.requestMethod = "GET"
        c.setRequestProperty("User-Agent", "MahmoodAI/0.8")
        c.inputStream.bufferedReader().use { htmlToText(it.readText()).take(maxChars) }
    }

    fun research(query: String, urls: List<String>): ResearchReport {
        val sources = urls.distinct().take(8).mapNotNull { url ->
            fetchText(url).getOrNull()?.let { SearchSource(url, extractTitle(it).ifBlank { url }, it) }
        }
        return ResearchReport(query, sources, sources.mapIndexed { i, s -> "[${i + 1}] ${s.url}" })
    }

    private fun htmlToText(html: String): String = html
        .replace(Regex("(?is)<script[^>]*>.*?</script>"), " ")
        .replace(Regex("(?is)<style[^>]*>.*?</style>"), " ")
        .replace(Regex("(?is)<[^>]+>"), " ")
        .replace("&nbsp;", " ").replace("&amp;", "&")
        .replace(Regex("\\s+"), " ").trim()

    private fun extractTitle(text: String): String = text.take(120).trim().ifBlank { "منبع وب" }

    fun searchUrl(query: String): String = "https://www.google.com/search?q=${URLEncoder.encode(query, "UTF-8")}"
}
