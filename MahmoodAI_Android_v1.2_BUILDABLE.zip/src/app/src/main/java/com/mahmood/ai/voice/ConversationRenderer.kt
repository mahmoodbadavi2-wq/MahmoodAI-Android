package com.mahmood.ai.voice

import com.mahmood.ai.data.VoiceProject

object ConversationRenderer {
    fun renderPlan(project: VoiceProject): String = buildString {
        append("TIMELINE v0.5\n")
        project.lines.forEachIndexed { i, line ->
            append("${i + 1}. ${line.speaker} | ${line.startMs}→${line.endMs}ms | overlap=${line.overlapMs}ms | sync=${line.syncWord ?: "-"}\n")
            append("   ${line.text}\n")
        }
        append("\nرندر واقعی WAV/MP3 به Provider صوتی مجاز متصل می‌شود؛ این ماژول فعلاً طرح زمان‌بندی دقیق تولید می‌کند.")
    }
}
