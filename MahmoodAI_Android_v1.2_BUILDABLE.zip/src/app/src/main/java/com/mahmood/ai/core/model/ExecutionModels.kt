package com.mahmood.ai.core.model

data class ExecutionRequest(val id:String, val text:String, val metadata:Map<String,String> = emptyMap())
data class ExecutionStage(val name:String, val state:String, val detail:String, val attempt:Int=0)
data class ExecutionResult(val requestId:String,val intent:String,val success:Boolean,val attempts:Int,val output:String,val stages:List<ExecutionStage>,val error:String?=null)
