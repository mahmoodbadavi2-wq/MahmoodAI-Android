package com.mahmood.ai.core.errors

sealed class AppError(message:String):Exception(message){
    class InvalidRequest:AppError("درخواست خالی است")
    class ToolUnavailable(intent:String):AppError("ابزار $intent در دسترس نیست")
    class VerificationFailed:AppError("نتیجه قابل تأیید نیست")
    class Timeout:AppError("زمان اجرای عملیات به پایان رسید")
}
