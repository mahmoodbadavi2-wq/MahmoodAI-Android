package com.mahmood.ai.agent

import com.mahmood.ai.build.BuildOrchestrator
import com.mahmood.ai.search.ResearchEngine
import com.mahmood.ai.network.VpnLink
import java.io.File

class ProductionToolsV10(private val research:ResearchEngine=ResearchEngine()){
 fun tools():Map<String,RuntimeTool>=mapOf(
  "SEARCH" to RuntimeTool{c->val r=research.research(c.request,limit=6);if(r.sources.isEmpty())ToolResult(false,error=r.warnings.joinToString("; ").ifBlank{"منبع پیدا نشد"}) else ToolResult(true,r.citations.joinToString("\n"){"[${it.id}] ${it.title} — ${it.url}"})},
  "NETWORK" to RuntimeTool{c->val p=VpnLink.parse(c.request.trim());if(p==null)ToolResult(false,error="کانفیگ پشتیبانی‌شده پیدا نشد")else ToolResult(true,"${p.type} ${p.host}:${p.port}")},
  "APP_FACTORY" to RuntimeTool{c->ToolResult(false,error="ساخت پروژه نیازمند Build workspace است؛ از App Factory UI استفاده کنید")},
  "LEGAL" to RuntimeTool{c->ToolResult(true,"درخواست حقوقی ساختاریافت شد؛ برای متن نهایی نیاز به اسناد پرونده دارد: ${c.request.take(400)}")},
  "VOICE" to RuntimeTool{c->ToolResult(true,"درخواست Voice دریافت شد؛ تحلیل صوت واقعی در Voice Pipeline انجام می‌شود.")},
  "GENERAL" to RuntimeTool{c->ToolResult(true,"درخواست ثبت شد؛ برای اجرای ابزار مشخص، دامنه عملیات را دقیق‌تر کنید.")}
 )
}
