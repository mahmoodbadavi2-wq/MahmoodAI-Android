package com.mahmood.ai.memory

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

class MemoryRepository(context:Context){
    private val prefs=context.getSharedPreferences("mahmood_memory_v1",Context.MODE_PRIVATE)
    fun put(key:String,value:String){val o=JSONObject(prefs.getString("data","{}")!!);o.put(key,value);prefs.edit().putString("data",o.toString()).apply()}
    fun get(key:String):String?=runCatching{JSONObject(prefs.getString("data","{}")!!).optString(key,null)}.getOrNull()
    fun keys():List<String>{val o=JSONObject(prefs.getString("data","{}")!!);val a=mutableListOf<String>();o.keys().forEach{a+=it};return a}
    fun clear(key:String){val o=JSONObject(prefs.getString("data","{}")!!);o.remove(key);prefs.edit().putString("data",o.toString()).apply()}
}
