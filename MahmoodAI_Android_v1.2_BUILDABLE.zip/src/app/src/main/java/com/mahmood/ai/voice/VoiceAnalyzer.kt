package com.mahmood.ai.voice

import kotlin.math.abs

data class VoiceAnalysisResult(
    val durationMs: Long,
    val estimatedWords: Int,
    val estimatedWpm: Int,
    val averagePauseMs: Long,
    val pitchRange: String,
    val intensity: String,
    val notes: List<String>
)

object VoiceAnalyzer {
    fun analyzeTextTiming(text: String, durationMs: Long? = null): VoiceAnalysisResult {
        val words = text.trim().split(Regex("\\s+")).filter { it.isNotBlank() }
        val d = durationMs ?: (words.size * 430L).coerceAtLeast(500L)
        val wpm = ((words.size * 60000.0) / d).toInt()
        return VoiceAnalysisResult(d, words.size, wpm, 180, "نیازمند AudioFeature extractor", "نیازمند RMS analysis",
            listOf("تحلیل دقیق Pitch/Intensity پس از اتصال AudioFeature pipeline انجام می‌شود.", "زمان‌بندی کلمات از متن فعلاً تخمینی است."))
    }
}
