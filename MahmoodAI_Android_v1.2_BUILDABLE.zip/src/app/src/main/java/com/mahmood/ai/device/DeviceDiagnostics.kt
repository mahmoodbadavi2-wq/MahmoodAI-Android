package com.mahmood.ai.device

import android.app.ActivityManager
import android.content.Context
import android.os.BatteryManager
import android.os.Build
import android.os.StatFs

class DeviceDiagnostics(private val context:Context) {
    fun snapshot():String {
        val am=context.getSystemService(ActivityManager::class.java)
        val mi=ActivityManager.MemoryInfo(); am?.getMemoryInfo(mi)
        val stat=StatFs(context.filesDir.absolutePath)
        val free=stat.availableBytes/1024/1024/1024; val total=stat.totalBytes/1024/1024/1024
        val bm=context.getSystemService(BatteryManager::class.java)
        val battery=bm?.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY) ?: -1
        return "RAM آزاد: ${mi.availMem/1024/1024}MB از ${mi.totalMem/1024/1024}MB\nحافظه: ${free}GB آزاد از ${total}GB\nباتری: ${battery}%\nAndroid: ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})"
    }
}
