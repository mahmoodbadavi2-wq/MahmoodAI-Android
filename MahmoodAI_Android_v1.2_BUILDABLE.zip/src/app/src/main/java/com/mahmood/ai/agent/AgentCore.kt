package com.mahmood.ai.agent

data class MissionPlan(val intent: String, val steps: List<String>, val verification: List<String>)

object AgentCore {
    fun plan(input: String): MissionPlan {
        val s=input.lowercase()
        val intent=when {
            s.contains("صدا")||s.contains("کلون")||s.contains("مکالمه")||s.contains("voice") -> "VOICE"
            s.contains("جستجو")||s.contains("تحقیق")||s.contains("منبع")||s.contains("search") -> "SEARCH"
            s.contains("vless")||s.contains("vmess")||s.contains("trojan")||s.contains("wireguard")||s.contains("vpn")||s.contains("کانفیگ") -> "NETWORK"
            s.contains("برنامه")||s.contains("اپ")||s.contains("android")||s.contains("windows")||s.contains("ساخت") -> "APP_FACTORY"
            s.contains("لایحه")||s.contains("شکایت")||s.contains("دادخواست")||s.contains("پرونده") -> "LEGAL"
            s.contains("فایل")||s.contains("pdf")||s.contains("docx")||s.contains("سند") -> "FILES"
            else -> "GENERAL"
        }
        val steps=when(intent){
            "VOICE"->listOf("Understand","Parse speakers/timing","Analyze prosody","Build timeline","Render/answer","Verify")
            "SEARCH"->listOf("Understand","Decompose query","Discover sources","Fetch/read","Extract evidence","Compare","Verify","Cite","Answer")
            "NETWORK"->listOf("Understand","Parse","Normalize","Validate","Diagnose","Generate profile","Verify")
            "APP_FACTORY"->listOf("Understand","Specify","Plan architecture","Generate","Validate files","Build","Parse errors","Repair","Test","Verify")
            "LEGAL"->listOf("Understand","Extract facts","Structure evidence","Detect contradictions","Map legal issues","Draft","Consistency check","Verify")
            "FILES"->listOf("Identify","Extract","Normalize","Index","Search/compare","Cite","Verify")
            else->listOf("Understand","Select capability","Execute","Verify")
        }
        return MissionPlan(intent,steps,listOf("Output completeness","Error state","Evidence/trace when applicable"))
    }
}
