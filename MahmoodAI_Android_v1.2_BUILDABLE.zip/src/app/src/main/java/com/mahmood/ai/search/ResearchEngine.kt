package com.mahmood.ai.search

import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.Locale

/** Provider-neutral research pipeline: Discover -> Fetch -> Extract -> Deduplicate -> Evidence -> Cite. */
data class DiscoveredSource(val url: String, val title: String = "", val snippet: String = "")
data class Evidence(val claim: String, val sourceUrl: String, val excerpt: String, val confidence: Double)
data class Citation(val id: Int, val url: String, val title: String)
data class VerifiedResearch(
    val query: String,
    val sources: List<SearchSource>,
    val evidence: List<Evidence>,
    val citations: List<Citation>,
    val warnings: List<String> = emptyList()
)

fun interface SearchDiscovery { fun discover(query: String, limit: Int): Result<List<DiscoveredSource>> }

/** Real web discovery without a provider API key. Use an API-backed implementation in production when available. */
class DuckDuckGoHtmlDiscovery : SearchDiscovery {
    override fun discover(query: String, limit: Int): Result<List<DiscoveredSource>> = runCatching {
        val endpoint = "https://html.duckduckgo.com/html/?q=${URLEncoder.encode(query, "UTF-8")}"
        val html = HttpFetcher.get(endpoint, 12_000, 15_000)
        Regex("(?is)<a[^>]+class=\\\"result__a\\\"[^>]+href=\\\"([^\\\"]+)\\\"[^>]*>(.*?)</a>")
            .findAll(html).mapNotNull { m ->
                val rawUrl = m.groupValues[1]
                val title = Html.clean(m.groupValues[2])
                val url = Regex("uddg=([^&]+)").find(rawUrl)?.groupValues?.get(1)?.let { java.net.URLDecoder.decode(it, "UTF-8") } ?: rawUrl
                if (url.startsWith("http")) DiscoveredSource(url, title) else null
            }.distinctBy { canonical(it.url) }.take(limit).toList()
    }

    private fun canonical(url: String): String = url.substringBefore('#').trimEnd('/').lowercase(Locale.US)
}

class ResearchEngine(private val discovery: SearchDiscovery? = DuckDuckGoHtmlDiscovery()) {
    fun research(query: String, seedUrls: List<String> = emptyList(), limit: Int = 8): VerifiedResearch {
        val discoveredResult = discovery?.discover(query, limit)
        val discovered = discoveredResult?.getOrElse { emptyList() }.orEmpty()
        val urls = (seedUrls.map(::canonical) + discovered.map { canonical(it.url) })
            .distinct().take(limit)
        val sourceByUrl = discovered.associateBy { canonical(it.url) }
        val sources = urls.mapNotNull { url ->
            fetch(url).getOrNull()?.let { body ->
                val meta = sourceByUrl[url]
                SearchSource(url, meta?.title?.ifBlank { null } ?: titleOf(body).ifBlank { url }, body)
            }
        }.distinctBy { canonical(it.url) }
        val citations = sources.mapIndexed { i, s -> Citation(i + 1, s.url, s.title) }
        val evidence = sources.flatMap { source ->
            sentenceEvidence(query, source)
        }.sortedByDescending { it.confidence }.take(30)
        val warnings = buildList {
            if (discoveredResult?.isFailure == true) add("Discovery failed: ${discoveredResult.exceptionOrNull()?.message ?: "unknown"}")
            if (discovered.isEmpty()) add("Discovery returned no sources; seed URLs may still be used.")
            if (sources.isEmpty()) add("No source could be fetched.")
            if (sources.size == 1) add("Only one independent source was available; cross-source verification is limited.")
        }
        return VerifiedResearch(query, sources, evidence, citations, warnings)
    }

    private fun sentenceEvidence(query: String, source: SearchSource): List<Evidence> {
        val queryTerms = query.lowercase(Locale.US).split(Regex("\\W+")).filter { it.length >= 3 }.toSet()
        return source.text.split(Regex("(?<=[.!?])\\s+"))
            .map { it.trim() }
            .filter { it.length >= 40 }
            .mapNotNull { sentence ->
                val lower = sentence.lowercase(Locale.US)
                val hits = queryTerms.count { lower.contains(it) }
                if (hits == 0) return@mapNotNull null
                val confidence = (0.35 + (hits.toDouble() / queryTerms.size.coerceAtLeast(1)) * 0.55).coerceAtMost(0.95)
                Evidence(query, source.url, sentence.take(600), confidence)
            }.take(8)
    }

    private fun fetch(url: String): Result<String> = runCatching { HttpFetcher.get(url, 10_000, 15_000).let(Html::clean) .take(60_000) }

    private fun titleOf(html: String): String = Regex("(?is)<title[^>]*>(.*?)</title>").find(html)?.groupValues?.get(1)?.let(Html::clean).orEmpty()
    private fun canonical(url: String): String = url.substringBefore('#').trimEnd('/').lowercase(Locale.US)
    fun searchUrl(query: String) = "https://html.duckduckgo.com/html/?q=${URLEncoder.encode(query, "UTF-8")}"
}

private object HttpFetcher {
    fun get(url: String, connectTimeout: Int, readTimeout: Int): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = connectTimeout; c.readTimeout = readTimeout; c.instanceFollowRedirects = true
        c.requestMethod = "GET"
        c.setRequestProperty("User-Agent", "MahmoodAI/0.8 (research client)")
        if (c.responseCode !in 200..399) error("HTTP ${c.responseCode}")
        return c.inputStream.bufferedReader().use { it.readText() }
    }
}

private object Html {
    fun clean(html: String): String = html
        .replace(Regex("(?is)<script[^>]*>.*?</script>"), " ")
        .replace(Regex("(?is)<style[^>]*>.*?</style>"), " ")
        .replace(Regex("(?is)<noscript[^>]*>.*?</noscript>"), " ")
        .replace(Regex("(?is)<[^>]+>"), " ")
        .replace("&nbsp;", " ").replace("&amp;", "&").replace("&quot;", "\"")
        .replace(Regex("\\s+"), " ").trim()
}
