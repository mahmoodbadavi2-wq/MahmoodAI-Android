package com.mahmood.ai

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.mahmood.ai.agent.AgentCore
import kotlinx.coroutines.launch
import com.mahmood.ai.ai.AppFactory
import com.mahmood.ai.data.ProjectStore
import com.mahmood.ai.device.DeviceDiagnostics
import com.mahmood.ai.install.AppInstaller
import com.mahmood.ai.legal.LegalStudio
import com.mahmood.ai.memory.MemoryStore
import com.mahmood.ai.network.NetworkTools
import com.mahmood.ai.network.VpnLink
import com.mahmood.ai.search.SearchAgent
import com.mahmood.ai.security.BiometricGate
import com.mahmood.ai.ui.MahmoodTheme
import com.mahmood.ai.ui.AgentPanel
import com.mahmood.ai.voice.*
import java.io.File

private val Cyan = Color(0xFF00D9FF)
private val Purple = Color(0xFF8B5CFF)
private val Pink = Color(0xFFFF4FD8)
private val Green = Color(0xFF47E6A1)

class MainActivity : ComponentActivity() {
    private val micPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) {}
    private val cameraPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) {}
    private val openFile = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri?.let { contentResolver.openInputStream(it)?.use { input ->
            File(cacheDir, "selected.apk").also { out -> out.outputStream().use(input::copyTo); lastApk = out }
        } }
    }
    private var lastApk: File? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            micPermission.launch(Manifest.permission.RECORD_AUDIO)
        }
        setContent { MahmoodApp() }
    }

    @Composable
    private fun MahmoodApp() {
        var tab by remember { mutableStateOf("خانه") }
        var command by remember { mutableStateOf("") }
        var text by remember { mutableStateOf("") }
        var heard by remember { mutableStateOf("") }
        var partial by remember { mutableStateOf("") }
        var output by remember { mutableStateOf("") }
        var vpn by remember { mutableStateOf("") }
        var project by remember { mutableStateOf<com.mahmood.ai.data.VoiceProject?>(null) }
        val context = LocalContext.current
        val voice = remember { VoiceEngine(context) }
        val memory = remember { MemoryStore(context) }
        val search = remember { SearchAgent(context) }
        val projects = remember { ProjectStore(context) }
        var recentProjects by remember { mutableStateOf(projects.recent()) }
        DisposableEffect(Unit) { onDispose { voice.release() } }

        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
            MahmoodTheme {
                Scaffold(
                    containerColor = MaterialTheme.colorScheme.background,
                    bottomBar = {
                        NavigationBar(containerColor = Color(0xFF0C0F1A)) {
                            listOf("خانه", "VOICE", "SEARCH", "ابزار", "ساخت").forEach { t ->
                                NavigationBarItem(
                                    selected = tab == t,
                                    onClick = { tab = t },
                                    icon = { Text(navIcon(t), fontSize = 18.sp) },
                                    label = { Text(t) }
                                )
                            }
                        }
                    }
                ) { pad ->
                    Box(Modifier.fillMaxSize().padding(pad)) {
                        LazyColumn(
                            Modifier.fillMaxSize().padding(horizontal = 16.dp),
                            contentPadding = PaddingValues(top = 18.dp, bottom = 28.dp),
                            verticalArrangement = Arrangement.spacedBy(14.dp)
                        ) {
                            item { TopBar() }
                            when (tab) {
                                "خانه" -> {
                                    item { CommandBar(command) { command = it } }
                                    item { AgentOrb() }
                                    item { QuickActions { tab = it } }
                                    item { StatusStrip() }
                                    item {
                                        SectionTitle("پروژه‌های اخیر", "همه چیز در یک Workspace")
                                        if (recentProjects.isEmpty()) EmptyProjects() else ProjectList(recentProjects)
                                    }
                                    item {
                                        SectionTitle("هسته هوشمند", "Understand → Plan → Execute → Verify")
                                        AgentPanel(command.ifBlank { "یک درخواست جدید وارد کن" }, onResult = { output = it })
                                    }
                                }
                                "VOICE" -> voiceScreen(
                                    text, { text = it }, partial, heard, output,
                                    { heard = it; text = it; partial = "" }, { partial = it }, { output = it },
                                    voice, project, { project = it }, { output = it }, { output = it }
                                )
                                "SEARCH" -> searchScreen(text, { text = it }, output, { output = it }, search)
                                "ابزار" -> toolsScreen(output, { output = it })
                                "ساخت" -> buildScreen(text, { text = it }, output, { output = it }, projects) { recentProjects = projects.recent() }
                            }
                            if (output.isNotBlank() && tab != "خانه") item { OutputCard(output) }
                        }
                    }
                }
            }
        }
    }

    @Composable private fun TopBar() {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
            Column {
                Text("MAHMOOD AI", fontWeight = FontWeight.Black, letterSpacing = 2.sp, fontSize = 20.sp)
                Text("PERSONAL INTELLIGENCE • v1.1 FINAL", color = MaterialTheme.colorScheme.primary, fontSize = 11.sp)
            }
            Box(Modifier.size(12.dp).clip(CircleShape).background(Green))
        }
    }

    @Composable private fun CommandBar(value: String, onChange: (String) -> Unit) {
        OutlinedTextField(
            value = value, onValueChange = onChange, modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(22.dp), singleLine = true,
            placeholder = { Text("هر کاری را طبیعی بگو…") },
            leadingIcon = { Text("✦", color = Cyan, fontSize = 22.sp) },
            trailingIcon = { Text("⌁", color = Purple, fontSize = 22.sp) }
        )
    }

    @Composable private fun AgentOrb() {
        val transition = rememberInfiniteTransition(label = "orb")
        val pulse by transition.animateFloat(0.92f, 1.08f, infiniteRepeatable(tween(1500), RepeatMode.Reverse), label = "pulse")
        Box(Modifier.fillMaxWidth().height(210.dp), contentAlignment = Alignment.Center) {
            Box(Modifier.size(190.dp * pulse).alpha(.16f).clip(CircleShape).background(Brush.radialGradient(listOf(Cyan, Purple, Color.Transparent))))
            Box(
                Modifier.size(138.dp).clip(CircleShape).background(Brush.radialGradient(listOf(Color(0xFF2B174B), Color(0xFF091B2B), Color(0xFF090A12))))
                    .border(1.dp, Brush.linearGradient(listOf(Cyan, Purple, Pink)), CircleShape), contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("✦", fontSize = 40.sp, color = Cyan)
                    Text("آماده‌ام", fontWeight = FontWeight.Bold)
                    Text("برای اجرا", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
    }

    @Composable private fun QuickActions(onOpen: (String) -> Unit) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            ActionCard("🎙", "VOICE", "صدا و مکالمه") { onOpen("VOICE") }
            ActionCard("🔎", "SEARCH", "تحقیق و وب") { onOpen("SEARCH") }
            ActionCard("🏗", "BUILD", "ساخت اپ") { onOpen("ساخت") }
        }
    }

    @Composable private fun ActionCard(icon: String, title: String, sub: String, onClick: () -> Unit) {
        Card(Modifier.weight(1f).height(105.dp).clickable(onClick = onClick), colors = CardDefaults.cardColors(containerColor = Color(0xFF111423))) {
            Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.SpaceBetween) {
                Text(icon, fontSize = 23.sp)
                Text(title, fontWeight = FontWeight.Bold, color = Cyan)
                Text(sub, fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }

    @Composable private fun StatusStrip() {
        Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(Color(0xFF0E1420)).padding(12.dp), horizontalArrangement = Arrangement.SpaceBetween) {
            StatusDot("AI", Green); StatusDot("VOICE", Cyan); StatusDot("SEARCH", Purple); StatusDot("LOCAL", Green)
        }
    }

    @Composable private fun StatusDot(label: String, color: Color) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(5.dp)) {
            Box(Modifier.size(7.dp).clip(CircleShape).background(color)); Text(label, fontSize = 9.sp, fontWeight = FontWeight.Bold)
        }
    }

    @Composable private fun SectionTitle(title: String, sub: String) {
        Column { Text(title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold); Text(sub, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant) }
    }

    @Composable private fun EmptyProjects() {
        Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF101321))) { Text("هنوز پروژه‌ای ساخته نشده؛ از Command Bar شروع کن.", Modifier.padding(16.dp), color = MaterialTheme.colorScheme.onSurfaceVariant) }
    }

    @Composable private fun ProjectList(items: List<String>) {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(items) { item ->
                val parts = item.split("|", limit = 2)
                Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF101321))) {
                    Row(Modifier.fillMaxWidth().padding(14.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(if (parts.size > 1) parts[1] else item, fontWeight = FontWeight.SemiBold)
                        Text(if (parts.isNotEmpty()) parts[0] else "PROJECT", color = Purple, fontSize = 10.sp)
                    }
                }
            }
        }
    }

    @Composable private fun voiceScreen(
        text: String, onText: (String) -> Unit, partial: String, heard: String, output: String,
        onHeard: (String) -> Unit, onPartial: (String) -> Unit, onError: (String) -> Unit,
        voice: VoiceEngine, project: com.mahmood.ai.data.VoiceProject?, onProject: (com.mahmood.ai.data.VoiceProject?) -> Unit,
        onOutput: (String) -> Unit, onAnalysis: (String) -> Unit
    ) {
        itemHeader("VOICE INTELLIGENCE", "Voice DNA • Analysis • Conversation Studio")
        itemField(text, onText, "دستور طبیعی برای صدا یا گفت‌وگو")
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = { voice.startListening(onText = onHeard, onPartial = onPartial, onError = onError) }) { Text("🎙 گوش دادن") }
            Button(enabled = text.isNotBlank(), onClick = { voice.speak(text, VoiceDirector.interpret(text)) }) { Text("🔊 پخش") }
            OutlinedButton(onClick = { voice.stopSpeaking() }) { Text("توقف") }
        }
        if (partial.isNotBlank()) infoCard("در حال تشخیص", partial)
        if (heard.isNotBlank()) infoCard("شنیده شد", heard)
        Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF101321))) {
            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                Text("CONVERSATION TIMELINE", color = Cyan, fontWeight = FontWeight.Bold)
                Button(enabled = text.isNotBlank(), onClick = { val p = ConversationDirector.parseNatural(text); onProject(p); onOutput(ConversationRenderer.renderPlan(p)) }) { Text("ساخت Timeline") }
                OutlinedButton(enabled = project != null, onClick = { val p = ConversationDirector.applyNaturalEdit(project!!, text); onProject(p); onOutput(ConversationRenderer.renderPlan(p)) }) { Text("اصلاح با زبان طبیعی") }
            }
        }
        Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF101321))) {
            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                Text("VOICE DNA", color = Purple, fontWeight = FontWeight.Bold)
                Text("Speed  •  Pitch  •  Energy  •  Pauses  •  Emotion  •  Emphasis", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Button(enabled = text.isNotBlank(), onClick = { val a = VoiceAnalyzer.analyzeTextTiming(text); onAnalysis("سرعت: ${a.estimatedWpm} WPM\nکلمات: ${a.estimatedWords}\nمدت: ${a.durationMs}ms\n${a.notes.joinToString("\n")}") }) { Text("تحلیل زمان‌بندی") }
            }
        }
    }

    @Composable private fun searchScreen(text: String, onText: (String) -> Unit, output: String, onOutput: (String) -> Unit, search: SearchAgent) {
        val scope = rememberCoroutineScope()
        var running by remember { mutableStateOf(false) }
        itemHeader("SEARCH WORKSPACE", "Search → Fetch → Extract → Compare → Verify → Cite")
        itemField(text, onText, "موضوع تحقیق")
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(enabled = text.isNotBlank() && !running, onClick = {
                running = true
                scope.launch {
                    val r = runCatching { kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) { com.mahmood.ai.search.ResearchEngine().research(text) } }
                    onOutput(r.fold({ buildString { append("تحقیق چندمنبعی\n\n"); it.evidence.take(10).forEach { e -> append("• ${e.excerpt} [${it.citations.indexOfFirst { c -> c.url == e.sourceUrl } + 1}]\n") }; append("\nمنابع:\n"); it.citations.forEach { c -> append("[${c.id}] ${c.title} — ${c.url}\n") }; if (it.warnings.isNotEmpty()) append("\nهشدار: ${it.warnings.joinToString(" | ")}") } }, { "خطای تحقیق: ${it.message}" }))
                    running = false
                }
            }) { Text(if (running) "در حال تحقیق…" else "تحقیق واقعی") }
            OutlinedButton(enabled = text.isNotBlank(), onClick = { search.openSearch(text) }) { Text("مرورگر") }
        }
        infoCard("v1.1 Research Engine", "کشف منبع، دریافت، استخراج، حذف تکرار، Evidence و Citation اکنون در خود اپ اجرا می‌شود.")
    }

    @Composable private fun toolsScreen(output: String, onOutput: (String) -> Unit) {
        itemHeader("TOOLBOX", "Device • Security • Files • APK")
        Button(onClick = { onOutput(DeviceDiagnostics(LocalContext.current).snapshot()) }) { Text("Diagnostics") }
        Button(onClick = { onOutput(BiometricGate.availability(LocalContext.current)) }) { Text("Biometric") }
        Button(onClick = { cameraPermission.launch(Manifest.permission.CAMERA) }) { Text("Face AI Permission") }
        Button(onClick = { openFile.launch(arrayOf("application/vnd.android.package-archive")) }) { Text("انتخاب APK") }
        Button(enabled = lastApk != null, onClick = { onOutput(if (AppInstaller.install(LocalContext.current, lastApk!!)) "درخواست نصب برای Android ارسال شد" else "APK نامعتبر است") }) { Text("نصب APK") }
    }

    @Composable private fun buildScreen(text: String, onText: (String) -> Unit, output: String, onOutput: (String) -> Unit, projects: ProjectStore, refresh: () -> Unit) {
        itemHeader("APP FACTORY", "Describe → Generate → Build → Repair → Verify")
        itemField(text, onText, "مثلاً: یک اپ فروشگاهی Android بساز")
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(enabled = text.isNotBlank(), onClick = { val r = com.mahmood.ai.ai.AppFactoryPipeline.prepare(LocalContext.current, text); val g = r.project!!; val p = g.plan; onOutput("Pipeline App Factory\n\n${r.steps.joinToString("\n") { "${it.state} ${it.name}: ${it.detail}" }}\n\nپلتفرم: ${p.platform}\nقابلیت‌ها: ${p.features.joinToString(" | ")}\nZIP: ${g.zipFile.name}"); projects.add(text.take(42), "APP"); refresh() }) { Text("ساخت طرح") }
            OutlinedButton(enabled = text.isNotBlank(), onClick = { val p = AgentCore.plan(text); onOutput("Intent: ${p.intent}\n\n${p.steps.joinToString("\n")}\n\nVERIFY\n${p.verification.joinToString("\n")}") }) { Text("Agent") }
        }
        infoCard("v1.1 App Factory", "تولید پروژه واقعی، اعتبارسنجی ساختار و مدل Build/Diagnose/Repair/Verify در Pipeline فعال است؛ اجرای Build نهایی در محیط دارای Android SDK و Gradle انجام می‌شود.")
    }

    @Composable private fun itemHeader(title: String, subtitle: String) {
        Column {
            Text(title, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Black)
            Text(subtitle, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }

    @Composable private fun itemField(value: String, onChange: (String) -> Unit, label: String) {
        OutlinedTextField(value, onChange, Modifier.fillMaxWidth().heightIn(min = 58.dp, max = 150.dp), shape = RoundedCornerShape(18.dp), label = { Text(label) })
    }

    @Composable private fun infoCard(title: String, body: String) {
        Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF101321))) { Column(Modifier.padding(14.dp)) { Text(title, color = Cyan, fontWeight = FontWeight.Bold); Spacer(Modifier.height(5.dp)); Text(body, color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 12.sp) } }
    }

    @Composable private fun OutputCard(output: String) {
        Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF11172A)), modifier = Modifier.fillMaxWidth()) { Column(Modifier.padding(15.dp)) { Text("RESULT", color = Green, fontWeight = FontWeight.Bold); Spacer(Modifier.height(7.dp)); Text(output) } }
    }

    private fun navIcon(tab: String) = when (tab) { "خانه" -> "⌂"; "VOICE" -> "◉"; "SEARCH" -> "⌕"; "ابزار" -> "⚙"; else -> "◇" }
}
