package com.mahmood.ai.agent

/** Default deterministic verifier/repair policies; domain tools can replace these. */
object DefaultResultVerifier : ResultVerifier {
    override suspend fun verify(request: String, result: ToolResult): Boolean =
        result.ok && result.output.isNotBlank() && !result.output.contains("ERROR", ignoreCase = true)
}

object DefaultResultRepairer : ResultRepairer {
    override suspend fun repair(request: String, failed: ToolResult, attempt: Int): ToolResult =
        ToolResult(false, error = "Repair requires a domain-specific repairer for attempt $attempt: ${failed.error ?: "verification failed"}")
}
