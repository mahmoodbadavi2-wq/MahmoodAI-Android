package com.mahmood.ai.face

import android.graphics.Rect
import com.google.mlkit.vision.face.Face
import com.google.mlkit.vision.face.FaceDetection
import com.google.mlkit.vision.face.FaceDetectorOptions
import com.google.mlkit.vision.common.InputImage

class FaceAnalyzer {
    private val detector=FaceDetection.getClient(FaceDetectorOptions.Builder().setPerformanceMode(FaceDetectorOptions.PERFORMANCE_MODE_FAST).setClassificationMode(FaceDetectorOptions.CLASSIFICATION_MODE_ALL).enableTracking().build())
    fun analyze(image:InputImage,onResult:(List<Face>)->Unit,onError:(Exception)->Unit){detector.process(image).addOnSuccessListener(onResult).addOnFailureListener(onError)}
    fun close(){detector.close()}
    fun label(face:Face):String="چهره ${face.trackingId?.toString() ?: "جدید"} | لبخند=${face.smilingProbability?.let{"%.0f%%".format(it*100)} ?: "-"} | چشم=${face.boundingBox.width()}x${face.boundingBox.height()}"
}
