package com.mahmood.ai.security

import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.spec.GCMParameterSpec

class KeystoreSecretStore(private val alias:String="mahmood_ai_master") {
    private val storeName="AndroidKeyStore"
    private fun key():java.security.Key {
        val ks=KeyStore.getInstance(storeName).apply{load(null)}
        if(!ks.containsAlias(alias)){
            val kg=KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES,storeName)
            kg.init(KeyGenParameterSpec.Builder(alias,KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT).setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE).build())
            kg.generateKey()
        }
        return ks.getKey(alias,null)
    }
    fun encrypt(value:String):String { val c=Cipher.getInstance("AES/GCM/NoPadding");c.init(Cipher.ENCRYPT_MODE,key());return Base64.encodeToString(c.iv+c.doFinal(value.toByteArray()),Base64.NO_WRAP) }
    fun decrypt(encoded:String):String { val all=Base64.decode(encoded,Base64.NO_WRAP);val iv=all.copyOfRange(0,12);val body=all.copyOfRange(12,all.size);val c=Cipher.getInstance("AES/GCM/NoPadding");c.init(Cipher.DECRYPT_MODE,key(),GCMParameterSpec(128,iv));return String(c.doFinal(body)) }
}
