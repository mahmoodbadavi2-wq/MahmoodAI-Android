package com.mahmood.ai.network

import java.net.InetAddress

object NetworkValidator {
    data class Report(val valid: Boolean, val checks: List<String>, val warnings: List<String>)
    fun validate(link: String): Report {
        val p = VpnLink.parse(link)
        if (p == null) return Report(false, listOf("✗ parse"), listOf("فرمت یا فیلدهای اصلی قابل تشخیص نیستند"))
        val checks = mutableListOf("✓ scheme=${p.type}", "✓ host=${p.host}", "✓ port=${p.port in 1..65535}")
        val warnings = mutableListOf<String>()
        if (p.port !in 1..65535) warnings += "پورت خارج از محدوده است"
        if (p.host.isBlank()) warnings += "Host خالی است"
        return Report(warnings.isEmpty(), checks, warnings)
    }
}
