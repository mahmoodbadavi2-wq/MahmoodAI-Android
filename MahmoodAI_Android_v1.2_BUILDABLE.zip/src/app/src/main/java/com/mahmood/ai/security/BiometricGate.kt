package com.mahmood.ai.security

import androidx.biometric.BiometricManager
import android.content.Context

object BiometricGate {
    fun availability(context:Context):String {
        val r=BiometricManager.from(context).canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_STRONG or BiometricManager.Authenticators.BIOMETRIC_WEAK)
        return when(r){BiometricManager.BIOMETRIC_SUCCESS->"احراز هویت زیستی آماده است"; BiometricManager.BIOMETRIC_ERROR_NO_HARDWARE->"سخت‌افزار زیستی موجود نیست"; BiometricManager.BIOMETRIC_ERROR_HW_UNAVAILABLE->"سخت‌افزار موقتاً در دسترس نیست"; else->"احراز هویت زیستی پیکربندی نشده است"}
    }
}
