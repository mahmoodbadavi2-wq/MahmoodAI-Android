package com.mahmood.ai.agent

import com.mahmood.ai.legal.LegalStudio
import com.mahmood.ai.network.VpnLink
import com.mahmood.ai.search.ResearchEngine
import com.mahmood.ai.voice.VoiceAnalyzer

class ProductionToolSet(private val research: ResearchEngine = ResearchEngine()) {
    fun tools(): Map<String, RuntimeTool> = mapOf(
        "SEARCH" to RuntimeTool { ctx ->
            val r = research.research(ctx.request, limit = 6)
            if (r.sources.isEmpty()) ToolResult(false, error = r.warnings.joinToString("; ").ifBlank { "منبع قابل دسترسی پیدا نشد" })
            else ToolResult(true, buildString {
                append("تحقیق تکمیل شد: ${r.sources.size} منبع\n")
                r.evidence.take(8).forEach { append("• ${it.excerpt} [${r.citations.indexOfFirst { c -> c.url == it.sourceUrl } + 1}]\n") }
                append("منابع:\n")
                r.citations.forEach { append("[${it.id}] ${it.title} — ${it.url}\n") }
                if (r.warnings.isNotEmpty()) append("هشدار: ${r.warnings.joinToString(" | ")}\n")
            })
        },
        "NETWORK" to RuntimeTool { ctx ->
            val link = ctx.request.substringAfter(":").let { if (ctx.request.contains("://")) ctx.request else "${ctx.request}" }
            val parsed = VpnLink.parse(link)
            if (parsed == null) ToolResult(false, error = "کانفیگ VLESS/VMess/Trojan/SS قابل پردازش نیست")
            else ToolResult(true, "نوع=${parsed.type}\nHost=${parsed.host}\nPort=${parsed.port}\nName=${parsed.name}\nاعتبار پایه: OK")
        },
        "APP_FACTORY" to RuntimeTool { ctx ->
            ToolResult(false, error = "برای ساخت پروژه از AppFactory.generateAndroidProject(context, instruction) استفاده شود.")
        },
        "LEGAL" to RuntimeTool { ctx ->
            val draft = LegalStudio.draft("لایحه", ctx.request, listOf(ctx.request), emptyList(), listOf("بررسی و اتخاذ تصمیم قانونی مقتضی"))
            ToolResult(true, draft.render())
        },
        "VOICE" to RuntimeTool { ctx ->
            val a = VoiceAnalyzer.analyzeTextTiming(ctx.request)
            ToolResult(true, "${a.estimatedWords} واژه | ${a.estimatedWpm} WPM | مدت ${a.durationMs}ms | RMS=${a.intensity}")
        }
    )
}
