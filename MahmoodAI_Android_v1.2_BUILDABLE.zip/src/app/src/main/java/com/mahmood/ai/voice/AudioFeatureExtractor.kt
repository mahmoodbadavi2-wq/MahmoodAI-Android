package com.mahmood.ai.voice

import java.io.File
import java.io.RandomAccessFile
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.sqrt

/** WAV PCM16 extractor. It intentionally rejects compressed/unknown formats instead of fabricating features. */
data class AudioFeatures(
    val sampleRate: Int,
    val channels: Int,
    val durationMs: Long,
    val rmsDb: Double,
    val peakDb: Double,
    val zeroCrossingRate: Double,
    val estimatedPitchHz: Double?,
    val notes: List<String> = emptyList()
)

object AudioFeatureExtractor {
    fun wavPcm16(file: File): Result<AudioFeatures> = runCatching {
        RandomAccessFile(file, "r").use { raf ->
            require(readAscii(raf, 4) == "RIFF") { "فایل WAV/RIFF نیست" }
            raf.skipBytes(4)
            require(readAscii(raf, 4) == "WAVE") { "فرمت WAVE نیست" }
            var sampleRate = 0
            var channels = 0
            var bits = 0
            var data = ByteArray(0)
            while (raf.filePointer < raf.length()) {
                val id = readAscii(raf, 4)
                val size = readLeInt(raf)
                when (id) {
                    "fmt " -> {
                        val format = readLeShort(raf)
                        channels = readLeShort(raf)
                        sampleRate = readLeInt(raf)
                        raf.skipBytes(6)
                        bits = readLeShort(raf)
                        if (size > 16) raf.skipBytes(size - 16)
                        require(format == 1) { "فقط PCM پشتیبانی می‌شود" }
                        require(bits == 16) { "فقط PCM 16-bit پشتیبانی می‌شود" }
                    }
                    "data" -> { data = ByteArray(size); raf.readFully(data); break }
                    else -> raf.skipBytes(size + (size and 1))
                }
            }
            require(sampleRate > 0 && channels > 0 && data.isNotEmpty()) { "داده صوتی معتبر پیدا نشد" }
            val samples = ShortArray(data.size / 2)
            for (i in samples.indices) samples[i] = ((data[i * 2 + 1].toInt() shl 8) or (data[i * 2].toInt() and 255)).toShort()
            val mono = if (channels == 1) samples else ShortArray(samples.size / channels) { i ->
                var sum = 0L; for (c in 0 until channels) sum += samples[i * channels + c].toLong(); (sum / channels).toInt().toShort()
            }
            var sumSq = 0.0; var peak = 0; var crossings = 0
            for (i in mono.indices) { val v = mono[i].toInt(); sumSq += v.toDouble() * v; peak = max(peak, abs(v)); if (i > 0 && ((mono[i - 1] < 0) != (mono[i] < 0))) crossings++ }
            val rms = sqrt(sumSq / mono.size.coerceAtLeast(1))
            val pitch = estimatePitch(mono, sampleRate)
            AudioFeatures(sampleRate, channels, mono.size * 1000L / sampleRate, db(rms), db(peak.toDouble()), crossings.toDouble() / mono.size, pitch,
                listOf("ویژگی‌ها از PCM واقعی استخراج شدند؛ Pitch در سکوت ممکن است null باشد."))
        }
    }

    private fun estimatePitch(x: ShortArray, sr: Int): Double? {
        val n = minOf(x.size, sr / 2); if (n < sr / 100) return null
        var energy = 0.0; for (i in 0 until n) energy += x[i].toDouble() * x[i]
        if (sqrt(energy / n) < 150) return null
        val minLag = sr / 500; val maxLag = sr / 70
        var bestLag = 0; var best = Double.NEGATIVE_INFINITY
        for (lag in minLag..minOf(maxLag, n - 1)) { var s = 0.0; for (i in 0 until n - lag) s += x[i].toDouble() * x[i + lag]; if (s > best) { best = s; bestLag = lag } }
        return if (bestLag > 0) sr.toDouble() / bestLag else null
    }
    private fun db(v: Double) = 20.0 * kotlin.math.log10(v.coerceAtLeast(1.0) / 32768.0)
    private fun readAscii(r: RandomAccessFile, n: Int) = ByteArray(n).also(r::readFully).toString(Charsets.US_ASCII)
    private fun readLeInt(r: RandomAccessFile): Int { val b=ByteArray(4); r.readFully(b); return (b[0].toInt() and 255) or ((b[1].toInt() and 255) shl 8) or ((b[2].toInt() and 255) shl 16) or ((b[3].toInt() and 255) shl 24) }
    private fun readLeShort(r: RandomAccessFile): Int { val b=ByteArray(2); r.readFully(b); return (b[0].toInt() and 255) or ((b[1].toInt() and 255) shl 8) }
}
