package com.mahmood.ai.agent

import com.mahmood.ai.core.events.AgentEvent
import com.mahmood.ai.core.events.AgentEventSink
import com.mahmood.ai.core.model.ExecutionRequest
import com.mahmood.ai.core.model.ExecutionResult
import com.mahmood.ai.core.model.ExecutionStage
import kotlinx.coroutines.withTimeout
import java.util.UUID

class AgentRuntimeV10(
    private val registry:ToolRegistry,
    private val verifier:ResultVerifier,
    private val policy:AgentPolicy=AgentPolicy(maxAttempts=3,timeoutMs=120_000),
    private val sink:AgentEventSink?=null
){
    suspend fun run(text:String):ExecutionResult=run(ExecutionRequest(UUID.randomUUID().toString(),text))
    suspend fun run(request:ExecutionRequest):ExecutionResult=withTimeout(policy.timeoutMs){
        require(request.text.isNotBlank())
        val plan=AgentCore.plan(request.text); val stages=mutableListOf<ExecutionStage>()
        fun emit(name:String,state:String,detail:String,attempt:Int=0){val st=ExecutionStage(name,state,detail,attempt);stages+=st;sink?.emit(AgentEvent.Stage(request.id,st))}
        sink?.emit(AgentEvent.Started(request.id,request.text))
        emit("Understand","✓","Intent=${plan.intent}")
        emit("Plan","✓",plan.steps.joinToString(" → "))
        val tool=registry.get(plan.intent)
        if(tool==null){emit("SelectTool","✗","ابزار موجود نیست");val r=ExecutionResult(request.id,plan.intent,false,0,"ابزار اجرایی برای ${plan.intent} ثبت نشده است.",stages,"ابزار اجرایی وجود ندارد");sink?.emit(AgentEvent.Finished(request.id,false,r.output));return@withTimeout r}
        emit("SelectTool","✓",plan.intent)
        var last=ToolResult(false,error="not executed")
        for(a in 1..policy.maxAttempts){
            emit("Execute","…","attempt=$a",a)
            last=tool.execute(ToolContext(request.text,a,request.metadata+mapOf("requestId" to request.id)))
            emit("Execute",if(last.ok)"✓" else "✗",last.output.ifBlank{last.error?:"خطا"},a)
            if(last.ok && verifier.verify(request.text,last)){emit("Verify","✓","نتیجه معتبر است",a);val r=ExecutionResult(request.id,plan.intent,true,a,last.output,stages);sink?.emit(AgentEvent.Finished(request.id,true,last.output));return@withTimeout r}
            emit("Verify","✗",last.error?:"Verification failed",a)
            if(a<policy.maxAttempts) emit("Repair","↻","اجرای مجدد با context خطا",a)
        }
        val out=last.error?:"نتیجه قابل تأیید نبود";emit("Finish","✗",out,policy.maxAttempts);val r=ExecutionResult(request.id,plan.intent,false,policy.maxAttempts,out,stages,out);sink?.emit(AgentEvent.Finished(request.id,false,out));r
    }
}
