package com.mahmood.ai.agent

/** Retry policy that re-runs the registered tool with explicit repair metadata. */
class ProductionRepairer(private val registry: ToolRegistry): ResultRepairer {
    override suspend fun repair(request:String, failed:ToolResult, attempt:Int):ToolResult {
        val intent=AgentCore.plan(request).intent
        val tool=registry.get(intent) ?: return ToolResult(false,error="ابزار $intent موجود نیست")
        return tool.execute(ToolContext(request, attempt, mapOf("repair" to "true", "previousError" to (failed.error ?: "verification"))))
    }
}
