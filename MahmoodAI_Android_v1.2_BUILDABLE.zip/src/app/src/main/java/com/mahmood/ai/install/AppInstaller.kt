package com.mahmood.ai.install

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.core.content.FileProvider
import java.io.File

object AppInstaller {
    fun install(context:Context, apk:File):Boolean {
        if(!apk.exists() || apk.extension.lowercase()!="apk") return false
        val uri:Uri=FileProvider.getUriForFile(context,"com.mahmood.ai.fileprovider",apk)
        val intent=Intent(Intent.ACTION_VIEW).apply { setDataAndType(uri,"application/vnd.android.package-archive"); addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK) }
        context.startActivity(intent); return true
    }
}
