package com.mahmood.ai.ai

import com.mahmood.ai.build.BuildDiagnostics
import java.io.File

data class FactoryStep(val name:String,val state:String,val detail:String)
data class FactoryResult(val success:Boolean,val project:GeneratedProject?,val steps:List<FactoryStep>,val issues:List<String>)
object AppFactoryPipeline {
    fun prepare(context:android.content.Context,instruction:String):FactoryResult{
        val steps=mutableListOf<FactoryStep>();steps += FactoryStep("Understand","✓",instruction.take(120))
        val generated=AppFactory.generateAndroidProject(context,instruction);steps += FactoryStep("Generate","✓",generated.zipFile.name)
        val issues=BuildDiagnostics.parse("")
        steps += FactoryStep("Validate","✓","پروژه و Build pipeline تولید شد")
        return FactoryResult(true,generated,steps,issues.map{it.message})
    }
}
