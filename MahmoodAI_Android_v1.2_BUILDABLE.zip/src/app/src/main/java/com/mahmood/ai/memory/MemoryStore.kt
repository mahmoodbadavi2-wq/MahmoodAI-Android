package com.mahmood.ai.memory

import android.content.Context

class MemoryStore(context:Context){
    private val p=context.getSharedPreferences("mahmood_memory",Context.MODE_PRIVATE)
    fun save(key:String,value:String){p.edit().putString(key,value).apply()}
    fun get(key:String):String=p.getString(key,"").orEmpty()
    fun keys():Set<String>=p.all.keys
}
