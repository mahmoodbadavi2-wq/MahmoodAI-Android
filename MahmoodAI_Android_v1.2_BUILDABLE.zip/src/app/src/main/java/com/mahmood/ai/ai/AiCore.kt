package com.mahmood.ai.ai

import android.content.Context
import com.mahmood.ai.memory.MemoryStore

data class AiConfig(val provider:String="manual",val baseUrl:String="",val model:String="",val apiKeyPresent:Boolean=false)
class AiCore(context:Context){
    private val memory=MemoryStore(context)
    fun classify(text:String):String=when {
        text.contains("صدا")||text.contains("مکالمه")||text.contains("کلون") -> "VOICE"
        text.contains("حقوق")||text.contains("لایحه")||text.contains("شکواییه") -> "LEGAL"
        text.contains("نصب")||text.contains("APK") -> "APP_INSTALL"
        text.contains("وی پی ان",true)||text.contains("vless",true)||text.contains("xray",true)->"NETWORK"
        text.contains("لگ")||text.contains("کند")||text.contains("رم") -> "DEVICE"
        else -> "GENERAL"
    }
    fun remember(k:String,v:String)=memory.save(k,v)
    fun recall(k:String)=memory.get(k)
}
