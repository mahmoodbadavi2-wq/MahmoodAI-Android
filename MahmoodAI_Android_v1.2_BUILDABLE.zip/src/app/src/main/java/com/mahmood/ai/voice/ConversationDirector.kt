package com.mahmood.ai.voice

import com.mahmood.ai.data.DialogueLine
import com.mahmood.ai.data.VoiceProject
import java.util.UUID

object ConversationDirector {
    private val lineRegex = Regex("(?i)(?:کلون|گوینده|speaker)\\s*(اول|اولی|یک|۱|1|دوم|دومی|دو|۲|2|\\d+)[^:：\\n]{0,30}(?:گفت|می[ -]?گوید|بگوید)[:：]?\\s*(.+?)(?=(?:\\n|$|(?:کلون|گوینده|speaker)\\s*(?:اول|اولی|یک|۱|1|دوم|دومی|دو|۲|2|\\d+)\\b))")

    fun parseNatural(instruction: String): VoiceProject {
        val matches = lineRegex.findAll(instruction).toList()
        val parsed = if (matches.isEmpty()) {
            listOf("clone_1" to instruction.trim())
        } else matches.map { m ->
            val n = m.groupValues[1]
            val speaker = if (n in setOf("اول", "اولی", "یک", "۱", "1")) "clone_1" else "clone_2"
            speaker to m.groupValues[2].trim().trim('.', '؟', '!', '،')
        }
        val sync = Regex("(?:از\\s+کلمه|کلمه)\\s*[«\"]?([^»\"\\s]+)[»\"]?", RegexOption.IGNORE_CASE).find(instruction)?.groupValues?.getOrNull(1)
        val simultaneous = instruction.contains("همزمان") || instruction.contains("قبل از اتمام") || instruction.contains("هم‌زمان")
        var cursor = 0L
        val lines = parsed.map { (speaker, text) ->
            val words = text.split(Regex("\\s+")).filter { it.isNotBlank() }
            val duration = (words.size * 430L).coerceAtLeast(700L)
            val start = cursor
            cursor += duration
            DialogueLine(speaker, text, start, start + duration, sync, if (simultaneous) 250 else 0, 1f, 1f, "طبیعی")
        }.toMutableList()
        if (simultaneous && lines.size >= 2) {
            val second = lines[1]
            lines[1] = second.copy(startMs = (second.startMs - second.overlapMs).coerceAtLeast(0))
        }
        return VoiceProject(UUID.randomUUID().toString(), "پروژه گفتگوی هوشمند", instruction, lines)
    }

    fun applyNaturalEdit(project: VoiceProject, instruction: String): VoiceProject {
        val m = Regex("(\\d+(?:[.,]\\d+)?)\\s*(?:ثانیه|sec|s)").find(instruction)
        if (m != null && (instruction.contains("دیرتر") || instruction.contains("زودتر"))) {
            val delta = ((m.groupValues[1].replace(',', '.').toDouble()) * 1000).toLong()
            val sign = if (instruction.contains("دیرتر")) 1 else -1
            val target = if (instruction.contains("کلون دوم") || instruction.contains("گوینده دوم")) "clone_2" else project.lines.getOrNull(1)?.speaker
            if (target != null) return project.copy(lines = project.lines.map { if (it.speaker == target) it.copy(startMs = (it.startMs + sign * delta).coerceAtLeast(0)) else it })
        }
        return project
    }
}
