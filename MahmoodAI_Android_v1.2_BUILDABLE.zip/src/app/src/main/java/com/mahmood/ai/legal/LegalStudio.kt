package com.mahmood.ai.legal

data class LegalDraft(val kind: String, val subject: String, val facts: List<String>, val evidence: List<String>, val requests: List<String>) {
    fun render(): String = buildString {
        appendLine("ریاست محترم مرجع قضایی")
        appendLine("با سلام و احترام")
        appendLine("موضوع: $subject")
        appendLine()
        appendLine("شرح و جهات دفاع/درخواست:")
        facts.forEachIndexed { i, f -> appendLine("${i + 1}. $f") }
        appendLine()
        appendLine("دلایل و مستندات:")
        evidence.forEachIndexed { i, e -> appendLine("${i + 1}. $e") }
        appendLine()
        appendLine("درخواست:")
        requests.forEachIndexed { i, r -> appendLine("${i + 1}. $r") }
    }
}

object LegalStudio {
    fun draft(kind: String, subject: String, facts: List<String>, evidence: List<String>, requests: List<String>) = LegalDraft(kind, subject, facts, evidence, requests)
    fun template(kind: String): String = draft(kind, when(kind) { "لایحه" -> "لایحه دفاعیه"; "شکواییه" -> "شکواییه"; else -> "دادخواست" }, emptyList(), emptyList(), emptyList()).render()
}
