package com.mahmood.ai.data

data class DialogueLine(val speaker:String,val text:String,val startMs:Long,val endMs:Long=0L,val syncWord:String?=null,val overlapMs:Long=0L,val speed:Float=1f,val pitch:Float=1f,val emotion:String="طبیعی")
data class VoiceProfile(val id:String,val name:String,val language:String="fa-IR",val authorized:Boolean=true)
data class VoiceProject(val id:String,val title:String,val instruction:String,val lines:List<DialogueLine>)
data class VpnProfile(val scheme:String,val host:String,val port:Int,val id:String="",val name:String="",val query:String="",val raw:String="")
