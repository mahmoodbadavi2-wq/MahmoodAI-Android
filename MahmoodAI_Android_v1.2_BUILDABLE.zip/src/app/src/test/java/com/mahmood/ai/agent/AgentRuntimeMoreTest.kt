package com.mahmood.ai.agent

import kotlinx.coroutines.runBlocking
import org.junit.Assert.*
import org.junit.Test

class AgentRuntimeMoreTest {
    @Test fun verifierFailureInvokesRepairAndCanRecover() = runBlocking {
        var calls = 0
        val registry = ToolRegistry(mapOf("search" to RuntimeTool { calls++; ToolResult(true, if (calls == 1) "bad" else "good") }))
        val verifier = ResultVerifier { _, r -> r.output == "good" }
        val repair = ResultRepairer { _, _, _ -> ToolResult(true, "good") }
        val result = AgentRuntime(registry, verifier, repair, AgentPolicy(3, 5_000)).run("جستجو درباره Kotlin")
        assertTrue(result.verified)
        assertEquals("good", result.result)
        assertEquals(2, result.attempts)
    }

    @Test fun missingToolIsNotReportedAsVerified() = runBlocking {
        val result = AgentRuntime(ToolRegistry(emptyMap()), DefaultResultVerifier, DefaultResultRepairer).run("تحقیق درباره اندروید")
        assertFalse(result.verified)
        assertTrue(result.result.contains("ابزار اجرایی"))
    }
}
