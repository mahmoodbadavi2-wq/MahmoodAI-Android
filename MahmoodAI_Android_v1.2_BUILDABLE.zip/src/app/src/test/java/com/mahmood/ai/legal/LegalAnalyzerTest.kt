package com.mahmood.ai.legal
import org.junit.Assert.assertTrue
import org.junit.Test
class LegalAnalyzerTest { @Test fun detectsEvidenceLines(){ val r=LegalAnalyzer.analyze("شرح واقعه\nگزارش کارشناسی موجود است\nدرخواست بررسی"); assertTrue(r.evidence.isNotEmpty()) } }
