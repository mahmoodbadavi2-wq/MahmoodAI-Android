package com.mahmood.ai.memory
import org.junit.Assert.assertEquals
import org.junit.Test
class MemorySearchTest { @Test fun ranksRelevantMemory(){ val r=MemorySearch.rank(mapOf("a" to "android voice assistant","b" to "coffee shop"),"android voice"); assertEquals("a",r.first().key) } }
