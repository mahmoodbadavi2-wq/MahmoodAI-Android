package com.mahmood.ai.agent

import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertTrue
import org.junit.Test

class AgentRuntimeTest {
    @Test fun successfulToolIsVerified() = runBlocking {
        val registry = ToolRegistry(mapOf("search" to RuntimeTool { ToolResult(true, "ok") }))
        val result = AgentRuntime(registry, DefaultResultVerifier, DefaultResultRepairer).run("جستجو درباره اندروید")
        assertTrue(result.verified)
        assertTrue(result.result == "ok")
    }
}
