package com.mahmood.ai.voice
import org.junit.Assert.assertEquals
import org.junit.Test
class VoiceTimelineTest { @Test fun pauseMovesFollowingSegments(){ val s=listOf(TimelineSegment("A","one",0,100),TimelineSegment("B","two",100,200)); assertEquals(150,VoiceTimeline.pauseBetween(s,0,50)[1].startMs) } }
