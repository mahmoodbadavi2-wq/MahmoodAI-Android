package com.mahmood.ai.agent

import kotlinx.coroutines.runBlocking
import org.junit.Assert.*
import org.junit.Test

class AgentRuntimeV10Test{
 @Test fun successfulExecutionIsVerified()=runBlocking{
  val r=AgentRuntimeV10(ToolRegistry(mapOf("GENERAL" to RuntimeTool{ToolResult(true,"ok result")})),ResultVerifier{_,x->x.ok&&x.output.contains("ok")}) .run("سلام")
  assertTrue(r.success); assertEquals(1,r.attempts)
 }
 @Test fun failedFirstAttemptRetriesAndRecovers()=runBlocking{
  var n=0
  val r=AgentRuntimeV10(ToolRegistry(mapOf("GENERAL" to RuntimeTool{n++;if(n==1)ToolResult(false,error="temporary") else ToolResult(true,"recovered")})),ResultVerifier{_,x->x.ok}) .run("سلام")
  assertTrue(r.success); assertEquals(2,r.attempts)
 }
}
