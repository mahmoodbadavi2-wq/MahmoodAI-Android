@echo off
setlocal
set "APP_HOME=%~dp0"
set "GRADLE_VERSION=9.6.0"
if defined JAVA_HOME goto :java_ok
where java >nul 2>nul
if %ERRORLEVEL% EQU 0 goto :java_ok
echo [ERROR] JDK 17 is required. Install JDK 17 and set JAVA_HOME.
exit /b 1
:java_ok
where gradle >nul 2>nul
if %ERRORLEVEL% EQU 0 goto :run_system
if exist "%APP_HOME%gradle\wrapper\gradle-wrapper.jar" goto :run_wrapper
if not exist "%APP_HOME%\.tools\gradle-%GRADLE_VERSION%\bin\gradle.bat" goto :bootstrap
call "%APP_HOME%\.tools\gradle-%GRADLE_VERSION%\bin\gradle.bat" -p "%APP_HOME%" %*
exit /b %ERRORLEVEL%
:run_wrapper
java -classpath "%APP_HOME%gradle\wrapper\gradle-wrapper.jar" org.gradle.wrapper.GradleWrapperMain %*
exit /b %ERRORLEVEL%
:run_system
gradle -p "%APP_HOME%" %*
exit /b %ERRORLEVEL%
:bootstrap
powershell -NoProfile -ExecutionPolicy Bypass -File "%APP_HOME%scripts\bootstrap_gradle_windows.ps1" -Version %GRADLE_VERSION%
if %ERRORLEVEL% NEQ 0 exit /b %ERRORLEVEL%
call "%APP_HOME%\.tools\gradle-%GRADLE_VERSION%\bin\gradle.bat" -p "%APP_HOME%" %*
exit /b %ERRORLEVEL%
