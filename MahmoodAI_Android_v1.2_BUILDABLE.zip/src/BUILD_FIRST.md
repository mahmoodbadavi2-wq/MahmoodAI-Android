# محمود AI v1.2 — اولین Build واقعی

این نسخه برای عبور از مرحله مهندسی به **APK قابل نصب** آماده شده است.

## Windows / Android Studio
1. Android Studio سازگار با AGP 9.4 را نصب کنید.
2. JDK 17 را انتخاب کنید.
3. SDK Platform 37 و Build Tools 36.0.0 را نصب کنید.
4. پوشه پروژه را باز کنید.
5. Gradle Sync را انجام دهید.
6. از Terminal ویندوز اجرا کنید:
   `scripts\\build_windows.ps1`
7. خروجی:
   `dist\\MahmoodAI-v1.2-debug.apk`

## اگر PowerShell اجازه اجرا نداد
در همان Terminal:
`Set-ExecutionPolicy -Scope Process Bypass`
سپس اسکریپت را اجرا کنید.

## تست دستی APK
- نصب و اجرای برنامه
- باز شدن UI و RTL
- اجرای Agent
- اجرای Research
- اجرای App Factory
- تست فایل TXT/MD/CSV/JSON/DOCX/PDF متنی
- تست Legal
- تست Network parser/diagnostics
- تست Voice و تحلیل WAV
- تست Memory
- تست Biometric/Keystore

**نکته:** خروجی برنامه Android، APK/AAB است؛ EXE ویندوزی نیست. اگر منظورتان «فایل اجرایی» برای Android است، همین APK خروجی درست است.
