$ErrorActionPreference="Stop"
Write-Host "=== Mahmood AI v1.2 Build Environment ==="
if ($env:JAVA_HOME) { Write-Host "JAVA_HOME: $env:JAVA_HOME" } else { Write-Host "JAVA_HOME: not set" }
$java = Get-Command java -ErrorAction SilentlyContinue
if (!$java) { throw "Java/JDK not found. Install JDK 17." }
java -version
$sdk = $env:ANDROID_HOME
if (!$sdk) { $sdk=$env:ANDROID_SDK_ROOT }
if (!$sdk) { Write-Warning "ANDROID_HOME/ANDROID_SDK_ROOT not set. Android Studio may still know the SDK path." } else { Write-Host "Android SDK: $sdk" }
if ($sdk -and (Test-Path (Join-Path $sdk "platforms\android-37"))) { Write-Host "android-37: OK" } else { Write-Warning "Android SDK platform 37 not detected." }
if ($sdk -and (Test-Path (Join-Path $sdk "build-tools\36.0.0"))) { Write-Host "build-tools 36.0.0: OK" } else { Write-Warning "Build Tools 36.0.0 not detected." }
Write-Host "Next: .\gradlew.bat testDebugUnitTest assembleDebug"
