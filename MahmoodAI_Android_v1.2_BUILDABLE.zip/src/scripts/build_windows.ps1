$ErrorActionPreference="Stop"
$root=Split-Path -Parent $PSScriptRoot
Set-Location $root
& "$root\scripts\VERIFY_BUILD_ENV.ps1"
& "$root\gradlew.bat" testDebugUnitTest assembleDebug
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
$apk=Join-Path $root "app\build\outputs\apk\debug\app-debug.apk"
if (!(Test-Path $apk)) { throw "APK was not produced: $apk" }
$out=Join-Path $root "dist"
New-Item -ItemType Directory -Force -Path $out | Out-Null
Copy-Item $apk (Join-Path $out "MahmoodAI-v1.2-debug.apk") -Force
Write-Host "BUILD SUCCESS: $out\MahmoodAI-v1.2-debug.apk"
