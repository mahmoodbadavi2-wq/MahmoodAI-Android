#!/usr/bin/env bash
set -euo pipefail
VERSION="${1:-9.6.0}"
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
TOOLS="$ROOT/.tools"
ZIP="$TOOLS/gradle-$VERSION-bin.zip"
DIR="$TOOLS/gradle-$VERSION"
mkdir -p "$TOOLS"
if [ ! -x "$DIR/bin/gradle" ]; then
  command -v curl >/dev/null || { echo "curl is required"; exit 1; }
  curl -fL "https://services.gradle.org/distributions/gradle-$VERSION-bin.zip" -o "$ZIP"
  unzip -q -o "$ZIP" -d "$TOOLS"
fi
echo "Gradle ready: $DIR"
