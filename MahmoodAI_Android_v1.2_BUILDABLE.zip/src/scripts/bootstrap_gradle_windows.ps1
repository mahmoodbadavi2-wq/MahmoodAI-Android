param([string]$Version="9.6.0")
$ErrorActionPreference="Stop"
$root=Split-Path -Parent $PSScriptRoot
$tools=Join-Path $root ".tools"
$zip=Join-Path $tools "gradle-$Version-bin.zip"
$dir=Join-Path $tools "gradle-$Version"
New-Item -ItemType Directory -Force -Path $tools | Out-Null
if (!(Test-Path (Join-Path $dir "bin\gradle.bat"))) {
  Write-Host "Downloading Gradle $Version..."
  Invoke-WebRequest -Uri "https://services.gradle.org/distributions/gradle-$Version-bin.zip" -OutFile $zip
  Expand-Archive -Path $zip -DestinationPath $tools -Force
}
Write-Host "Gradle ready: $dir"
