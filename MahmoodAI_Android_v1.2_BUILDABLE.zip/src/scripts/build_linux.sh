#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
./gradlew testDebugUnitTest assembleDebug
mkdir -p dist
cp -f app/build/outputs/apk/debug/app-debug.apk dist/MahmoodAI-v1.2-debug.apk
printf '\nBUILD SUCCESS: %s\n' "$ROOT/dist/MahmoodAI-v1.2-debug.apk"
